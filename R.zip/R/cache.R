# Environment for caching data etc
cache <- new.env(parent = emptyenv())

#' 判断是否有此缓存
#'
#' @param name
#'
#' @export
#'
is_cached <- function(name){
  exists(name, envir = cache)
}

#' 为某个key设置缓存值
#'
#' @param name
#' @param value
#'
#' @export
#'
set_cache <- function(name, value) {
  #   message("Setting ", name, " in cache")
  assign(name, value, envir = cache)
  value
}

#' 以key为索引获取缓存值
#'
#' @param name
#'
#' @export
#'
get_cache <- function(name) {
  #   message("Getting ", name, " from cache")
  get(name, envir = cache)
}

#' 直接获取值或者计算并缓存
#'
#' @param name
#' @param computation
#'
#' @export
#'
cache_computation <- function(name, computation) {
  if (is_cached(name)) {
    get_cache(name)
  } else {
    res <- force(computation)
    set_cache(name, res)
    res
  }
}

#' 把缓存写入文件
#'
#' @param name
#'
#' @export
#'
write_cache <- function(name){
  if (missing(name))
    stop("需要设置name")

  if (!is_cached(name))
    stop("还未缓存%s", name)

  require(feather)
  require(futile.logger)

  filename <- paste0(name, ".feather")
  filepath <- cache_location(NULL, filename)
  flog.debug("writing to %s ", filepath)
  write_feather(get_cache(name), filepath)
}

#'
#' 从磁盘读取缓存内容
#'
#' @param name 索引名称
#' @param columns 需要读取的列明
#'
#' @export
#'
read_cache <- function(name, columns = NULL){
  filename <- paste0(name, ".feather")
  filepath <- cache_location(NULL, filename)
  read_feather(filepath, columns)
}

#' Title
#'
#' @param path
#' @param filename
#'
#' @return
#'
#' @examples
cache_location <- function(path = NULL, filename) {
  if (!is.null(path)) {
    # Check that path is a directory and is writeable
    if (!file.exists(path) || !file.info(path)$isdir) {
      stop(path, " is not a directory", call. = FALSE)
    }
    if (!is_writeable(path)) stop("Can not write to ", path, call. = FALSE)
    return(file.path(path, filename))
  }

  tmp <- tempdir()
  if (is_writeable(tmp)) return(file.path(tmp, filename))

  stop("Could not find writeable location to cache data", call. = FALSE)
}

#' Title
#'
#' @param x
#'
#' @return
#'
#' @examples
is_writeable <- function(x) {
  unname(file.access(x, 2) == 0)
}