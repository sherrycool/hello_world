  #' KDJ 金叉选股
#' @param start 轮动行业选择开始日期
#' @param end 轮动行业选择结束日期
#' @param shenwan28_index 申万行业
#' @return 两个用于轮动的行业
#' @import futile.logger
#' @export
screen_rr<- function(current_day)
{
  if (!n_workday(current_day, 0, "CNSESH") || !n_workday(current_day, 0, "CNSESZ"))
  {
    flog.info(paste(current_day, "is not workday!"))
    return(FALSE)
  }
  row_data <- data_manage(current_day)
  if(is.logical(row_data))
  {
    return(FALSE)
  }
  cu_data        <- subset(row_data, TDATE == current_day)
  screened_list  <-

  symbols       <- unique(row_data[row_data$TDATE == current_day, "SYMBOL"])
  screened_list <- c()
  for (symbol in symbols)
  {
    kdj  <- kdj_value(row_data, symbol)
    if(is.logical(kdj))
    {
      next
    }
    flag1  <- (kdj[2, "K"] > kdj[2,"D"] & kdj[2, "J"] > kdj[2, "D"] & kdj[2,"J"] <= 20 &
               kdj[1, "K"] < kdj[1, "D"] & kdj[1, "J"] < kdj[1, "D"])
    flag2  <- average_case(symbol, row_data)
    if(flag1 & flag2)
    {
      screened_list <- c(screened_list, symbol)
    }
  }
  cu_data          <- row_data[row_data$TDATE == current_day,
                               c("TDATE", "SYMBOL", "EXCHANGE", "TCLOSE")]
  screened_result  <- subset(cu_data, SYMBOL %in% screened_list)
  if (nrow(screened_result) == 0)
  {
    return(FALSE)
  }
  return(screened_result)
}


#' 计算kdj每日k,d,j
#' @param row_data 原始数据
#' @param symbol 计算的股票代码
#' @return 返回某一天kdj值
kdj_value <- function(row_data, symbol, n = 9, m = 3, l = 3)
{
  cu_symbol  <- subset(row_data, SYMBOL == symbol)
  index_set        <- data.frame(matrix(nrow = 0, ncol = 6))
  names(index_set) <- c("TDATE", "SYMBOL", "TCLOSE", "K", "D", "J")
  dates            <- cu_symbol[-c(1:(n+1)),"TDATE"]
  for (date in dates)
  {
    if (date == dates[1])
    {
      k_val <- 50
      d_val <- 50
    }
    else
    {
      be_index    <- index_set[nrow(index_set),]
      symbol_data <- tail(subset(cu_symbol, TDATE <= date), n)
      rsv_val     <- (tail(symbol_data$TCLOSE, 1) - min(symbol_data$LOW)) /
        (max(symbol_data$HIGH) - min(symbol_data$LOW)) * 100
      k_val   <- (m - 1) / m * be_index$K + 1 / m * rsv_val
      d_val   <- (l - 1) / l * be_index$D + 1 / l * k_val
    }
    j_val   <- 3 * k_val - 2 * d_val
    tclose  <- cu_symbol[cu_symbol$TDATE == date, "TCLOSE"]
    item    <- data.frame(TDATE = date, SYMBOL = symbol, TCLOSE = tclose,
                          K = k_val, D = d_val, J = j_val)
    index_set <- rbind(index_set, item)
  }
   if (nrow(index_set) < 2)
   {
     return(FALSE)
   }
  return(tail(index_set, 2))
}

#' 计算股票20日的10日均线
#' @param current_day 选股当天日期
#' @param  row_data  选股数据
#' @return 选股需要的一些指标
screen_index <- function(current_day, row_data)
{
  colnames              <- c("TDATE", "EXCHANGE", "TCLOSE", "HIGH", "LOW")
  screened_index        <- data.frame(matrix(nrow = 0, ncol = 7))
  names(screened_index) <- c("SYMBOL", "MA", colnames)
  symbols  <- unique(row_data[row_data$TDATE == current_day, "SYMBOL"])
  for (symbol in symbols)
  {
    cu_symbol <- subset(row_data, SYMBOL == symbol)
    if (nrow(cu_symbol) <= 35)
    {
      next
    }
    ma   <- SMA(cu_symbol$TCLOSE, 10)
    ma   <- na.omit(ma)
    all_date        <- cu_symbol$TDATE
    date            <- all_date[(nrow(cu_symbol) - length(ma) + 1):nrow(cu_symbol)]
    symbol_data     <- data.frame(TDATE = date, SYMBOL = rep(symbol, length(ma)), MA = ma)
    screened_list   <- merge(cu_symbol[, colnames], symbol_data, by = "TDATE")
    screened_index  <- rbind(screened_index, screened_list)
  }
  return(screened_index)
}

#' average case
#' @name average_case
#' @param stock_item 股票数据
#' @return bool
average_case <- function(symbol, row_data)
{
  cu_sy  <- row_data[row_data$SYMBOL == symbol, ]
  cu_vo  <- tail(cu_sy, 1)$VOTURNOVER
  me_vo  <- mean(tail(cu_sy, 5)$VOTURNOVER)
  flag   <- ifelse(cu_vo > me_vo, TRUE, FALSE)
  return(flag)
}

#' 选择数据
#' @param current_day 选股当天日期
#' @return 所选数据
#' @import RODBC
data_manage  <- function(current_day)
{
  mydb <- odbcConnect(dsn = "caihua")
  be_cuday <- min(j.tdays("CNSESH", start_date = current_day, daycounts = -100))
  sql      <- paste("SELECT TDATE, SYMBOL, EXCHANGE, TCLOSE, HIGH, LOW, VOTURNOVER FROM CHDQUOTE_ADJ ",
                    "WHERE TDATE >=", be_cuday, " AND TDATE <= ", current_day)
  row_data <- sqlQuery(mydb, sql)
  if (nrow(row_data) == 0)
  {
    return(FALSE)
  }
  return(row_data)
}
