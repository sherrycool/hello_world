#' Load a R source file
#' @param filename filename to load, without the directory path it lies in
#' @param directory directory path the target file lies in, default if current wd
#' @export
#' @examples
#'  load_file("util.R")
#'  load_file("util.R", "test.R", "file.R")
#'  load_file("util.R", "../lib")
load_file <- function(..., directory=getwd())
{
  for (filename in list(...))
  {
    source(paste(directory, filename, sep="/"), encoding = "utf-8")
  }
}


#' Load config files for Startegy
#' @param env env name for the config file to load
#' @export
load_config <- function(env=NULL)
{
  ## determine env
  if(is.null(env))
  {
    env <- Sys.getenv("ENV", "dev")
    if (Sys.info()[["sysname"]] == "Windows"){
      env <- "dev"
    }
  }
  futile.logger::flog.info("using ENV: %s", env)

  config_names <- c("common", env, "usr")

  ## determine the STRA_ROOT
  stra_root <- normalizePath(Sys.getenv("STRA_ROOT", file.path(getwd(), "../..")))
  stra_dir <-  normalizePath(getwd())
  name_matrix <- expand.grid(c(stra_root, stra_dir), c("config", "conf"), config_names)

  paths <- sapply(data.frame(t(name_matrix)), paste, collapse="/")
  paths <- paste0(paths, ".R")
  paths <- paths[file.exists(paths)]
  conf_env <- new.env()
  for (cfile in paths)
  {
    futile.logger::flog.info("loading config file: %s ...", cfile)
    source(cfile, conf_env)
  }
  .GlobalEnv$.__config_env <- conf_env

  if(is_qbt()) {
    flog.appender(http_log_appender)
  }
}


#' get a config value
#' @param config_key the key
#' @return the value or NULL
#' @export
get_config <- function(config_key)
{
  conf_env <- .GlobalEnv$.__config_env
  if (!is.environment(conf_env)) {
    load_config()
    conf_env <- .GlobalEnv$.__config_env
  }
  return(conf_env[[config_key]])
}
