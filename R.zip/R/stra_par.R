library(stringr)

.onLoad <- function(libname, pkgname)
{
  .__set_par()
}


#' Predicate if the strategy is running under the qbt platform
#' @return TRUE if running under qbt, else FALSE
#' @export is_qbt is.web
#' @aliases is.web
is_qbt <- function(){
  Sys.getenv("QUANBITTLE") != ""
}
is.web <- is_qbt


#' @import stringr
.__set_par <- function(){
  if (is_qbt()) {
    return(NULL);
  }
  args <- commandArgs(TRUE)
  if (length(args) < 2) {
    return();
  }
  env <- environment(is_qbt)
  args <- args[2:length(args)]
  reg <- "^(?:(.*)\\.)?([^=]+)=(.*)$"
  args_table <- str_match(args, reg)
  args_table[is.na(args_table[, 2]), 2] <- "stra"
  for (idx in seq(nrow(args_table))){
    if (is.na(args_table[idx, 1])){
      warning(paste("Ignoring argument:", args[idx]), call. = FALSE, immediate. = TRUE);
      next
    }
    entry <- args_table[idx, 2]
    key <- args_table[idx, 3]
    val <- args_table[idx, 4]
    setter <- paste("par", entry, "set", sep = "_")
    if (is.null(env[[setter]])){
      warning(paste("Ignoring argument:", args[idx]), call. = FALSE, immediate. = TRUE);
      next
    }
    func <- env[[setter]]
    func(key, val)
  }
}


#' run the strategy
#' @export
run <- function(){
  if (is_qbt()) {
    return(NULL);
  }

  is_script <- (length(commandArgs(F))>2 & commandArgs(F)[2] == "--slave")

  if(!is_script) {
    return(NULL);
  }


  args <- commandArgs(TRUE)
  entry <- args[1]
  if (is.na(entry)) {
    entry <- "main"
  }
  if (!exists(entry)) {
    writeLines(paste("Bad entry: ", entry))
    q("no", 2)
  }
  real_entry <- globalenv()[[entry]]
  if (!is.function(real_entry)) {
    writeLines(paste("Bad entry: ", entry))
    q("no", 3)
  }
  real_entry()
}


.__par_closure_gg <- function() {
  pars <- list()
  function(par_class) {
    if (!is.list(pars[[par_class]])){
      pars[[par_class]] <<- list()
    }
    getter <- function(key, default=NULL) {
      if (is.null(pars[[par_class]][[key]])) {
        return(default);
      }
      return(pars[[par_class]][[key]]);
    }

    setter <- function(key, value) {
      old_val <- pars[[par_class]][[key]]
      pars[[par_class]][[key]] <<- value;
      value
    }
    return(c(getter, setter));
  }
}


.__par_closure_gen <- .__par_closure_gg()
.__entries <- c(
  "__qbt", "stra", "misc",
  "screen", "timing", "trading",
  "risk_mng", "portf_mng", "asset_mng",
  "backtest", "perf_analy"
)


#' @export par.__qbt par.__qbt.set
#' @export par.stra par.stra.set
#' @export par.misc par.misc.set
#' @export par.screen par.screen.set
#' @export par.timing par.timing.set
#' @export par.trading par.trading.set
#' @export par.risk_mng par.risk_mng.set
#' @export par.portf_mng par.portf_mng.set
#' @export par.asset_mng par.asset_mng.set
#' @export par.backtest par.backtest.set
#' @export par.perf_analy par.perf_analy.set
#'
#' @export par___qbt par___qbt_set
#' @export par_stra par_stra_set
#' @export par_misc par_misc_set
#' @export par_screen par_screen_set
#' @export par_timing par_timing_set
#' @export par_trading par_trading_set
#' @export par_risk_mng par_risk_mng_set
#' @export par_portf_mng par_portf_mng_set
#' @export par_asset_mng par_asset_mng_set
#' @export par_backtest par_backtest_set
#' @export par_perf_analy par_perf_analy_set

for (entry in .__entries) {
  getter_name <- paste("par", entry, sep = ".")
  setter_name <- paste("par", entry, "set", sep = ".")
  .__par_closures <- .__par_closure_gen(paste("par", entry, sep = "."))
  environment(is_qbt)[[getter_name]] <- .__par_closures[[1]]
  environment(is_qbt)[[setter_name]] <- .__par_closures[[2]]
}

for (entry in .__entries) {
  getter_name <- paste("par", entry, sep = "_")
  setter_name <- paste("par", entry, "set", sep = "_")
  .__par_closures <- .__par_closure_gen(paste("par", entry, sep = "."))
  environment(is_qbt)[[getter_name]] <- .__par_closures[[1]]
  environment(is_qbt)[[setter_name]] <- .__par_closures[[2]]
}

rm(entry, getter_name, setter_name)
rm(.__par_closure_gg)
