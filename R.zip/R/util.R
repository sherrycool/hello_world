#' Return turnover zhangfu
#'
#' @param data 数据
#' @param date 日期
#' @param nday 天数
#' @param volumes 交易量
#' @param stock 股票
#' @param exchange 交易所
#'
#' @return turnover zhangfu
#' @export exchange_ratio exchangeRatio
#' @aliases exchangeRatio
#' @examples
#' exchange_ratio()
exchange_ratio <- function(data, date, nday, volumes, stock, exchange)
{
  week1_volume <- averageVolume(date$week1_1, date$week1_2, nday, volumes, stock, exchange)
  week2_volume <- averageVolume(date$week2_1, date$week2_2, nday, volumes, stock, exchange)
  if (week1_volume[1] == -1 & week2_volume[1] == -1)
  {
    return( (data[2] - data[1]) / data[1])
  }
  else
  {
    if (week1_volume[1] != -1 & week2_volume[1] == -1)
    {
      week1_average <- week1_volume[2]
      week2average <- week1_volume[3]
    }
    else
    {
      if (week2_volume[1] != -1 & week1_volume[1] == -1)
      {
        week1_average <- week2_volume[1]
        week2_average <- week2_volume[2]
      }
      else
      {
        week1_average <- week1_volume[2]
        week2_average <- week2_volume[2]
      }
    }
  }
  return( (data[2] / week2_average - data[1] / week1_average) / (data[1] / week1_average))
}
exchangeRatio <- exchange_ratio

#' Return average volumes in a period time and the volume before and after these days
#'
#' @param start the start date
#' @param end the end date
#' @param nday the total number of trade day
#' @param volumes changed volumes
#' @param symbol the stock symbol
#' @param exchange the market symbol
#' @return average volumes in a period time and the volume before and after these days
#' @export average_volume averageVolume
#' @aliases averageVolume
average_volume <- function(start, end, nday, volumes, symbol, exchange)
{
  data <- volumes[(volumes$symbol == symbol) & (volumes$exchange == exchange) &
                    (volumes$date >= start) & (volumes$date <= end), ]
  ## 从股量变动信息中选出在给定时间段内给定股票的信息
  if (nrow(data) == 0)
  {
    return(c(-1, -1, -1)) # 如果没有就返回全-1的数组
  }
  data <- data[order(data[, "date"], decreasing = FALSE), ]
  ## 按时间升序排序
  if (nrow(data) > 0)
  {
    rownames(data) <- 1:nrow(data) # 排序完成之后重命名一下rowname
  }

  ## 从start到第一个变动日期的股量计算
  sumup <- workDayCount(start, data$date[1], exchange) * data$beforevolume[1]
  ## 从变动日期到下一个变动日期的股量计算
  i <- 2
  while (!is.na(data[i, "aftervolume"]))
  {
    ## 如果没有第i行，访问data[i] dataframe会返回全na的行
    sumup <- sumup + workDayCount(data$date[i - 1], data$date[i], exchange) *
      data$aftervolume[i - 1]
    i <- i + 1
  }
  ## 最后一个变动日期到end的股量计算
  ## 因为要包括end，所以调用的时候用end+1
  sumup <- sumup + workDayCount(data$date[i - 1], end + 1, exchange) * data$aftervolume[i - 1]
  return(c(data$beforevolume[1], sumup / nday, data$aftervolume[i - 1]))
}
averageVolume <- average_volume


#' Change the int type vector to character type of six-bit.
#'
#' @param stocks input stocks vector
#' @return the six-bit character vector
#' @export to_character toCharacter
#' @aliases toCharacter
#' @examples
#' to_character(c(600321,591))
to_character <- function(stocks)
{
  stocks <- as.character(stocks)
  for (stock in stocks)
  {
    if (nchar(stock) < 6)
    {
      stocks[which(stocks == stock)] <- paste(c(rep("0", 6 - nchar(stock)), stock),
                                              sep = "", collapse = "")
    }
  }
  return(stocks)
}
toCharacter <- to_character


#' Return the trading day date before or after the given date of nday trading days.if nday equals
#' to zero,return TURE or FALSE weather the given date is a trading day or not.
#'
#' @param start the given date
#' @param nday the number of trading days
#' @param exchange market symbol
#' @return a date or bool value
#' @export n_workday nWorkDay
#' @aliases nWorkDay
#' @examples
#' n_workday(20160415, 5, "CHSESH")
#' n_workday(20160415, 0, "CHSESH")
n_workday <- function(start, nday, exchange)
{
  if (nday >= 0)
  {
    sql  <- paste("select * from ", get_config("TABLE_EXCHANGE_TRADE_DAY"),
                  " Where EXCHANGE='", exchange,
                  "' AND TDATE >= ", start, " order by tdate", sep = "")
    data <- fetch_mysql(sql, max = nday + 1)

    end  <- max(data[, "TDATE"])
    if (nday == 0 & start == end) return(TRUE)
    if (nday == 0 & start != end) return(FALSE)
    return(end)
  }
  else
  {
    i <- 1
    while (nday < 0)
    {
      end <- as.numeric(format(as.Date(-i, format = "%Y%m%d", origin = as.character(start)),
                               format = "%Y%m%d"))
      i <- i + 1
      sql <- paste("select * from ", get_config("TABLE_EXCHANGE_TRADE_DAY"),
                   " Where EXCHANGE='", exchange,
                   "' AND TDATE=", end, " order by TDATE", sep = "")
      data <- fetch_mysql(sql, max = 1)

      if (nrow(data) > 0)
      {
        nday <- nday + 1
      }
    }
    return(end)
  }
}
nWorkDay <- n_workday


#' Whether the stock_data items"s number is nday after eliminating the NAs
#'
#' @param stock_data stock data, a data frame
#' @param start the start date
#' @param end the end date
#' @param nday the number of trading days
#'
#' @return the num of trade day
#' @export is_valid_stock1 isValidStock1 isNoMissingStock
#' @aliases isValidStock1 isNoMissingStock
is_valid_stock1 <- function(stock_data, start, end, nday)
{
  data_select <- stock_data[stock_data$TDATE >= start & stock_data$TDATE <= end, ]
  if (nrow(data_select) == nday)
  {
    return(TRUE)
  }
  else
  {
    return(FALSE)
  }
}
isValidStock1 <- is_valid_stock1
isNoMissingStock <- is_valid_stock1


#' Return the information of changed volume between start and end
#'
#' @param channel Database connection handle
#' @param stocks the stock symbols
#' @param exchange market symbol
#' @param start the start date
#' @param end the end date
#' @param changed_data
#'
#' @return information of changed volume
#' @export vol_changed volChanged
#' @aliases volChanged
vol_changed <- function(channel, stocks, exchange, start, end, changed_data)
{
  changed_res <- as.data.frame(matrix(nrow = 0, ncol = 5))
  names(changed_res) <- c("date", "symbol", "exchange", "before_volume", "after_volume")
  i <- 0

  for (stock in stocks)
  {
    i <- i + 1

    data <- changed_data[changed_data[, "SYMBOL"] == stock, ]
    data <- na.omit(data)
    if (nrow(data) == 0)
    {
      next
    }

    data <- data[order(data[, "PUBLISHDATE"], decreasing = FALSE), ]
    if (nrow(data) > 0)
    {
      rownames(data) <- 1:nrow(data)
    }

    date <- as.numeric(format(data$PUBLISHDATE, format = "%Y%m%d"))
    after_volume <- data$SCSTC27 * 10000
    sql <- paste(
      "select ",
      "caihua.SecurityCode.companycode, caihua.SCSTC.SCSTC27, caihua.SCSTC.PUBLISHDATE from ",
      get_config("TABLE_SECURITY_CODE"), ", ", get_config("TABLE_STOCK_CAPITAL"),
      " where caihua.SecurityCode.symbol='", stock,
      "' and caihua.SecurityCode.exchange='", exchange,
      "' and caihua.SecurityCode.companycode=caihua.SCSTC.companycode", sep = "")
    data_row <- fetch_mysql(sql)
    data_row <- data_to_character(data_row)
    data_row <- na.omit(data_row)
    data_row <- data_row[order(data_row[, "PUBLISHDATE"], decreasing = FALSE), ]

    if (nrow(data_row) > 0)
    {
      rownames(data_row) <- 1:nrow(data_row)
    }

    name <- as.numeric(row.names(data_row[data_row[, "PUBLISHDATE"] == data$PUBLISHDATE[1], ])) - 1

    before_volume <- data_row[name:(name + nrow(data) - 1), "SCSTC27"] * 10000

    if (name == 0)
    {
      before_volume[1] <- data_row$SCSTC27[1] * 10000
    }

    symbol <- rep(stock, nrow(data))
    exchange_name <- rep(exchange, nrow(data))
    frame <- data.frame(date, symbol, exchange_name, before_volume, after_volume)

    frame <- na.omit(frame)
    changed_res <- rbind(changed_res, frame)
  }
  return(changed_res)
}
volChanged <- vol_changed


#' Return the num of trade day of specified market between start and end
#'
#' @param channel  Database connection handle
#' @param start start date
#' @param end end date
#' @param exchange market symbol
#' @return the num of trade day
#' @export workday_count workDayCount
#' @aliases workDayCount(channel, 20160101, 20160415, "CNSESH")
#' @examples
#' workday_count()
workday_count <- function(channel, start, end, exchange)
{
  sql <- paste("select TDATE from ", get_config("TABLE_EXCHANGE_TRADE_DAY"), " Where EXCHANGE='",
               exchange, "' AND TDATE>=", start, " AND TDATE<", end, sep = "")
  data <- fetch_mysql(sql)
  return(nrow(data))
}
workDayCount <- workday_count


#' Make up the suspended data of stock_data with the LCLOSE of the before day
#'
#' @param the original stock data
#' @return made up stock_data
#' @export halt_make_up haltMakeup
#' @aliases haltMakeup
#' @examples
#' halt_make_up(stock_data)
halt_make_up <- function(stock_data)
{
  for (i in 1:nrow(stock_data))
  {
    if (stock_data[i, "TCLOSE"] == 0)
    {
      stock_data[i, "TOPEN"]  <- stock_data[i, "LCLOSE"]
      stock_data[i, "TCLOSE"] <- stock_data[i, "LCLOSE"]
      stock_data[i, "HIGH"]   <- stock_data[i, "LCLOSE"]
      stock_data[i, "LOW"]    <- stock_data[i, "LCLOSE"]
    }
  }
  return(stock_data)
}
haltMakeup <- halt_make_up


#' Gather the data weekly
#'
#' @param stock_data stock data
#' @return gathered data
#' @export to_week_data toWeekData
#' @aliases toWeekData
#' @examples
#' to_week_data(stock_data)
to_week_data <- function(stock_data)
{
  res <- data.frame(matrix(nrow = 0, ncol = ncol(stock_data)))
  names(res) <- names(stock_data)
  for (i in 1:(nrow(stock_data) / 5))
  {
    res[i, ] <- stock_data[i * 5 - 4, ]
    res[i, "TCLOSE"] <- stock_data[i * 5, "TCLOSE"]
    res[i, "HIGH"]   <- max(stock_data[(i * 5 - 4):(i * 5), "HIGH"])
    res[i, "LOW"]    <- min(stock_data[(i * 5 - 4):(i * 5), "LOW"])
    res[i, "VATURNOVER"] <- sum(as.numeric(stock_data[(i * 5 - 4):(i * 5), "VATURNOVER"]))
    res[i, "VOTURNOVER"] <- sum(as.numeric(stock_data[(i * 5 - 4):(i * 5), "VOTURNOVER"]))
  }
  if (nrow(res) > 0)
  {
    rownames(res) <- 1:nrow(res)
  }
  return(res)
}
toWeekData <- to_week_data


#' Fetch the whole data of specified exchange and between date start and end
#'
#' @param start the begin date
#' @param end the end date
#' @param exchange exchange "CNSESH" or "CNSESZ"
#'
#' @return the whole data of specified exchange and between date start and end
#' @export fetch_row_data fetchRowData
#' @aliases fetchRowData
#' @examples
#' fetch_row_data(20160411, 20160415, "CNSESH")
fetch_row_data <- function(start, end, exchange)
{
  sql <- paste("SELECT * FROM ", get_config("TABLE_STOCK_QUOTE_ADJ"),
               " WHERE TDATE>=", start, " AND TDATE<=",
               end, " AND EXCHANGE='", exchange, "'", sep = "")
  row_data <- fetch_mysql(sql)
  row_data <- data_to_character(row_data)
  return(row_data)
}
fetchRowData <- fetch_row_data


#' Fetch the Private placement data of specified exchange and specified day
#' including issueid,exchange,tclose,symbol,implpubdate,projectbegdate,
#' porjectenddate,issueminprice,lpenddate
#'
#' @param channel Database connection handle
#' @param date the specified day
#' @param exchange exchange symbol
#' @return Private placement data
#' @export fetch_row_dingzeng_data fetchRowDingzengData
#' @aliases fetchRowDingzengData
#' @examples
#' fetch_row_dingzeng_data(channel, 20160411, "CNSESH")
fetch_row_dingzeng_data <- function(date, exchange)
{
  sql <- paste("select TQ_SK_PROFINPLAN.CSRCAGREEDATE, TQ_SK_PROFINPLAN.ISSUEID,
               CHDQuote.EXCHANGE, CHDQuote.TClose, SecurityCode.SYMBOL,
               TQ_SK_PROFINPLAN.IMPLPUBDATE, TQ_SK_PROFINPLAN.PROJECTBEGDATE,
               TQ_SK_PROFINPLAN.PROJECTENDDATE, TQ_SK_PROFINPLAN.ISSUEMINPRICE,
               TQ_SK_LPCFIN.LPENDDATE from ",
               get_config("TABLE_FINANCING_PLAN"), ",", get_config("TABLE_SECURITY_CODE"), ",",
               get_config("TABLE_STOCK_LPCFIN"), ",", get_config("TABLE_STOCK_QUOTE_ADJ"),
               " where (TQ_SK_PROFINPLAN.ISSUETYPE=02 or TQ_SK_PROFINPLAN.ISSUETYPE=06)
               and TQ_SK_PROFINPLAN.COMPCODE=SecurityCode.COMPANYCODE
               and TQ_SK_LPCFIN.ISSUEID=TQ_SK_PROFINPLAN.ISSUEID
               and securitycode.SYMBOL=CHDQuote.SYMBOL and CHDQuote.TDATE=", date,
               " and TQ_SK_PROFINPLAN.PROJECTENDDATE>=", date, " AND CHDQuote.EXCHANGE='",
               exchange, "'", sep = "")

  row_data <- fetch_mysql(sql)
  row_data <- data_to_character(row_data)
  return(row_data)
}
fetchRowDingzengData <- fetch_row_dingzeng_data


#' Get the total num of stocks which are current of each stocks of the specified exchange
#' and the day between the start day and end day
#'
#' @param start  the begin date
#' @param end the end date
#' @param exchange exchange symbol
#' @return the current stock num of each stock
#' @export fetch_row_changed_data fetchRowChangedData
#' @aliases fetchRowChangedData
#' @examples
#' fetch_row_changed_data(20160411, 20160415, "CNSESH")
fetch_row_changed_data <- function(start, end, exchange)
{
  sql <- paste("select caihua.SecurityCode.symbol,caihua.SecurityCode.exchange,
               caihua.SecurityCode.companycode,
               caihua.SCSTC.SCSTC27, caihua.SCSTC.PUBLISHDATE from ",
               get_config("TABLE_SECURITY_CODE"), ",", get_config("TABLE_STOCK_CAPITAL"),
               " where caihua.SecurityCode.exchange='", exchange,
               "' and caihua.SecurityCode.companycode=caihua.SCSTC.companycode
               and caihua.SCSTC.publishdate>=to_date('", start, "' ,'YYYYMMDD')
               and caihua.SCSTC.publishdate<=to_date('", end, "', 'YYYYMMDD') ",
               sep = "")

  row_data <- fetch_mysql(sql)
  row_data <- data_to_character(row_data)
  return(row_data)
}
fetchRowChangedData <- fetch_row_changed_data


#' Return the index information of specified market
#'
#' @param start  the begin date
#' @param end the end date
#' @param exchange exchange symbol
#' @return index information of specified market
#' @export fetch_index_row_data fetchIndexRowData
#' @aliases fetchIndexRowData
#' @examples
#' fetch_index_row_data(channel, 20160411, 20160415, "CNSESH")
fetch_index_row_data <- function(start, end, exchange)
{
  symbol <- ifelse(exchange == "CNSESZ", "399001", "000001")
  sql <- paste("SELECT TDATE,SYMBOL,SNAME,EXCHANGE,LCLOSE,TOPEN,TCLOSE,HIGH,
               LOW,VATURNOVER,VOTURNOVER FROM ", get_config("TABLE_INDEX_QUOTE"),
               " WHERE TDATE>=", start, " AND TDATE<=", end,
               " AND EXCHANGE='", exchange, "' AND SYMBOL='",
               symbol, "'", sep = "")
  row_data <- fetch_mysql(sql)
  row_data <- data_to_character(row_data)
  return(row_data)
}
fetchIndexRowData <- fetch_index_row_data


#' Get the specified symbol data from the origianl data
#'
#' @param row_data original data
#' @param start the begin date
#' @param end the end date
#' @param symbol stock symbol
#' @param exchange exchange symbol
#' @return the specified symbol data from the origianl data
#' @export fetch_stock_data fetchStockData
#' @aliases fetchStockData
#' @examples
#' fetch_index_row_data(row_data, 20160411, 20160415, 600004, "CNSESH")
fetch_stock_data <- function(row_data, start, end, symbol, exchange)
{
  stock_data <- row_data[row_data$SYMBOL == symbol & row_data$EXCHANGE == exchange &
                           row_data$TDATE >= start & row_data$TDATE <= end, ]
  stock_data <- stock_data[order(stock_data[, "TDATE"], decreasing = FALSE), ]
  if (nrow(stock_data) > 0)
  {
    rownames(stock_data) <- 1:nrow(stock_data)
  }
  return(stock_data)
}
fetchStockData <- fetch_stock_data


#' Return the aggregate of an attribution of the data if option is an aggregate function
#' or the attribution data of the data of the date if option is a date
#'
#' @param stock_data original data
#' @param column specified attribution
#' @param option aggregate function or a date
#' @param start the begin date
#' @param end the end date
#' @return a specifiled day date or a return of aggregate function
#' @export fetch_column_data fetchColumnData
#' @aliases fetchColumnData
#' @examples
#' fetch_column_data(rowData, "TCLOSE", "min", 20160411, 20160415)
#' fetch_column_data(rowData, "TCLOSE", 20160411)
fetch_column_data <- function(stock_data, column, option, start = 0, end = 0)
{
  if (option != "max" & option != "min" & option != "sum" & option != "mean")
  {
    return(stock_data[stock_data$TDATE == option, column])
  }

  stock_data <- stock_data[stock_data$TDATE >= start & stock_data$TDATE <= end, ]
  if (option == "max")
  {
    return(max(stock_data[, column]))
  }
  if (option == "min")
  {
    return(min(stock_data[, column]))
  }
  if (option == "sum")
  {
    return(sum(as.numeric(stock_data[, column])))
  }
  if (option == "mean")
  {
    return(mean(stock_data[, column]))
  }
}
fetchColumnData <- fetch_column_data


#' Return the zhang fu of a stock between start and end
#'
#' @param stockData stock data
#' @param start the begin date
#' @param end the end date
#' @return zhang fu
#' @export zhang_fu zhangfu
#' @aliases zhangfu
#' @examples
#' zhang_fu(stock_data,20160101,20160419)
zhang_fu <- function(stock_data, start, end)
{
  baseValue <- fetch_column_data(stock_data, "LCLOSE", start)
  aboveValue <- fetch_column_data(stock_data, "TCLOSE", end)
  return( (aboveValue - baseValue) / baseValue)
}
zhangfu <- zhang_fu


#' Return the zhen fu of a stock between start and end
#'
#' @param stockData stock data
#' @param start the begin date
#' @param end the end date
#' @return zhen fu
#' @export zhen_fu zhenfu
#' @aliases zhenfu
#' @examples
#' zhen_fu(stock_data,20160101,20160419)
zhen_fu <- function(stock_data, start, end)
{
  baseValue <- fetchColumnData(dataSelect, "LCLOSE", start)
  maxValue <- fetchColumnData(dataSelect, "HIGH", "max", start, end)
  minValue <- fetchColumnData(dataSelect, nday, "LOW", "min", start, end)
  return( (maxValue - minValue) / baseValue)
}
zhenfu <- zhen_fu


#' Whether the stock of one day is *ST
#'
#' @param stock_data stock data
#' @param day the date
#' @return ST stocks name
#' @export is_ST_stock isSTStock
#' @aliases isSTStock
#' @examples
#' is_ST_stock(stock_data, 20160101)
is_ST_stock <- function(stock_data, day)
{
  sname <- stock_data[stock_data$TDATE == day, "SNAME"]
  return(grepl("*.ST.*", sname))
}
isSTStock <- is_ST_stock


#' Change the date from 2014-01-01 to 20040101
#'
#' @param date date like "2014-01-01"
#' @return date like "20040101"
#' @export date_format DateFormat
#' @aliases DateFormat
#' @examples
#' date_format("2014-01-01")
date_format <- function(date)
{
  return(as.numeric(paste(substr(date, 1, 4), substr(date, 6, 7), substr(date, 9, 10), sep = "")))
}
DateFormat <- date_format


#' Get TCLOSE
#'
#' @param filecode:sz(SNSESZ,no fuquan),sh(SNSESH,no fuquan),
#'                 szq(SNSESZ,qian fuquan),shq(SNSESH,qian fuquan),
#'                 szh(,hou fuquan),shh(SNSESH,hou fuquan)
#' @return TCLOSE of specified kind
#' @export get_hq getHq
#' @aliases getHq
#' @examples
#' get_hq("sz")
get_hq <- function(filecode)
{
  switch(filecode,
         sz = read.csv(sz_quote_path, header = TRUE),
         sh = read.csv(sh_quote_path, header = TRUE),
         szq = read.csv(szq_quote_path, header = TRUE),
         shq = read.csv(shq_quote_path, header = TRUE),
         szh = read.csv(szh_quote_path, header = TRUE),
         shh = read.csv(shh_quote_path, header = TRUE),
         other = paste("no such market code: ", market))
}
getHq <- get_hq


#' Get TCLOSE
#'
#' @param stkcode stock symbol(int)
#' @param hq_date date as 20150505
#' @param market the market symbol,or "sh","sz"
#' @param fuquan default bufuquan, if "q", qianfuquan, if "h", houfuquan
#' @return tclose
#' @export get_close_price getClosePrice
#' @aliases getClosePrice
#' @examples
#' get_close_price(600004,20150205,"sh","q")
get_close_price <- function(stkcode, hq_date, market = "", fuquan = "")
{
  hq_str <- paste("hq", fuquan, sep = "")

  if (!exists(hq_str, envir = .GlobalEnv))
  {
    shhq <- getHq(paste("sh", fuquan, sep = ""))
    szhq <- getHq(paste("sz", fuquan, sep = ""))
    hq <- cbind(shhq, szhq)
    hq$DATETIME <- as.numeric(as.character.Date(as.Date(hq$DATETIME), "%Y%m%d"))
    assign(hq_str, hq, envir = .GlobalEnv)
  }

  hq <- get(hq_str, .GlobalEnv)
  sz_stkcode_colname <- paste("X", ToCharacter(stkcode), ".SZ", sep = "")
  sh_stkcode_colname <- paste("X", ToCharacter(stkcode), ".SH", sep = "")
  close_price <- NULL
  if (market == "")
  {
    close_price <- .subset2(hq, sz_stkcode_colname)[hq$DATETIME == hq_date]
    if (is.null(close_price))
    {
      close_price <- .subset2(hq, sh_stkcode_colname)[hq$DATETIME == hq_date]
    }
  }
  else
  {
    close_price <- switch(
      market,
      sz = close_price <- .subset2(hq, sz_stkcode_colname)[hq$DATETIME == hq_date],
      sh = close_price <- .subset2(hq, sh_stkcode_colname)[hq$DATETIME == hq_date],
      other = NULL)
  }
  return(close_price)
}
getClosePrice <- get_close_price


#' print the buy and sell point on the quotation chart
#'
#' @param start the start date
#' @param end the end date
#' @param symbol the stock symbol
#' @param exchange the market symbol
#' @param signal_list list include TDATE and SIGNAL returned by strategy
#' @return no
#' @export print_point PrintPoint
#' @aliases PrintPoint
#' @examples
#' print_point(20160101, 20160421, 600004, "CNSESH", signal_list)
print_point <- function(start, end, symbol, exchange, signal_list)
{
  if (!("quantmod" %in% (.packages())))
  {
    library(quantmod)
  }

  sql <- paste("SELECT TDATE,TCLOSE FROM ", get_config("TABLE_STOCK_QUOTE_ADJ"),
               " WHERE TDATE>=", start,
               " AND　TDATE<=", end, " AND EXCHANGE='", exchange, "' AND SYMBOL=", symbol, sep = "")
  index <- fetch_mysql(sql)
  index <- index[order(index$TDATE), ]

  index <- subset(index, index$TCLOSE != 0)

  ID <- seq(1:nrow(index))
  index <- cbind(index, ID)

  ## 信号
  signal_list <- signal_list[, -3]
  ## 买卖信号
  buy <- subset(signal_list, signal_list$SIGNAL == 1)
  sell <- subset(signal_list, signal_list$SIGNAL == -1)
  ## 画图用
  buy_point <- subset(index, index$TDATE %in% buy$TDATE)
  sell_point <- subset(index, index$TDATE %in% sell$TDATE)

  ## 时间序列转换
  index[, 1] <- paste(substr(index[, 1], 1, 4), substr(index[, 1], 5, 6),
                      substr(index[, 1], 7, 8), sep = "-")
  index[, 1] <- as.Date(index[, 1], origin = "1970-01-01")
  index <- as.xts(index[, c("TCLOSE"), drop = FALSE], order.by = index$TDATE)
  chartSeries(index, theme = chartTheme("white"))

  ## 看多,红色
  for (i in 1:nrow(buy_point))
  {
    points(buy_point[i, ]$ID, buy_point[i, ]$TCLOSE, col = "red", pch = 19)
  }
  ## 看空,黑色
  for (i in 1:nrow(sell_point))
  {
    points(sell_point[i, ]$ID, sell_point[i, ]$TCLOSE, col = "black", pch = 19)
  }
}
PrintPoint <- print_point
