#' choose : ph
#'
#' 股价创新高选股策略
#' @name price highest chosen
#' @param m 时间变量
#' @param date operating date
#' @return 选出来的股票
#' @export
#' @import RODBC
#' @import dplyr
ph_chosen <- function(date = 20160901, m = 260, w = 5, mm = 20, s = 30, q = 60)
{
  mydb <- odbcConnect(dsn = "caihua")
  before_day <- date - 10000
  stop_day <- date + 10000
  sql_1 <- paste0("select SYMBOL,TDATE,TCLOSE,HIGH,EXCHANGE from CHDQUOTE_ADJ where TDATE>=", before_day, " and TDATE<=", stop_day," and EXCHANGE in ('CNSESZ','CNSESH') order by SYMBOL,TDATE")
  raw_data <- sqlQuery(mydb, sql_1)
  symbols <- unique(raw_data$SYMBOL)
  show_list <- data.frame(TDATE  = NA, SYMBOL = NA,	TCLOSE = NA, WRATE = NA, MRATE = NA, SRATE = NA, QRATE = 60, WCLOSE = NA,	MCLOSE = NA, SCLOSE = NA, QCLOSE = NA)
  for (symbol in symbols)
  {
    data_single <- filter(raw_data, SYMBOL == symbol)
    data_single <- arrange(data_single, TDATE)
    if (nrow(filter(data_single, TDATE < date)) < 100 | !(date %in% data_single$TDATE)){
      next
    }
    data_before <- filter(data_single, TDATE <= date)
    if (tail(data_before$TCLOSE, 1) >= max(data_before[-length(data_before), "HIGH"]))
    {
      tlcose <- NA; wclose <- NA; mclose <- NA; sclose <- NA; qclose <- NA
      wrate <- NA; mrate <- NA; srate <- NA; qrate <- NA
      tclose <- data_single$TCLOSE[which(data_single$TDATE == date)]
      wclose <- data_single$TCLOSE[which(data_single$TDATE == date) + w - 1]
      mclose <- data_single$TCLOSE[which(data_single$TDATE == date) + mm - 1]
      sclose <- data_single$TCLOSE[which(data_single$TDATE == date) + s - 1]
      qclose <- data_single$TCLOSE[which(data_single$TDATE == date) + q - 1]
      wrate <- wclose / tclose - 1
      mrate <- mclose / tclose - 1
      srate <- sclose / tclose - 1
      qrate <- qclose / tclose - 1
      show_single <- data.frame(TDATE = date, SYMBOL = symbol, TCLOSE = tclose, WRATE = wrate, MRATE = mrate, SRATE = srate, QRATE = qrate, WCLOSE = wclose,	MCLOSE = mclose, SCLOSE = sclose, QCLOSE = qclose)
      show_single$SYMBOL <- handle_symbols(show_single$SYMBOL)
      show_list <- rbind(show_list, show_single)
    }
  }
  show_list <- show_list[-1, ]
  return(show_list)
}


#' handle the symbol to be XXXXXX character
#'
#' @name handle symbols
#' @param symbols vector
#' @return symbols characterS
handle_symbols <- function(symbols)
{
  for (i in 1:length(symbols))
  {
    if(nchar(symbols[i] < 6))
    {
      while(nchar(symbols[i]) < 6)
      {
        symbols[i] <- paste0('0', symbols[i])
      }
    }
  }
  symbols
}

#' get symbols active after 20160101
#' @export
#' @import RODBC
get_symbols_choose <- function()
{
  mydb <- odbcConnect(dsn = 'caihua')
  sql <- "SELECT DISTINCT SYMBOL FROM CHDQUOTE_ADJ WHERE TDATE >= 20160101"
  symbol_raw <- sqlQuery(mydb, sql)

  symbol <- as.character(symbol_raw[[1]])

  for (i in 1:length(symbol))
  {
    if(nchar(symbol[i] < 6))
    {
      while(nchar(symbol[i]) < 6)
      {
        symbol[i] <- paste0('0', symbol[i])
      }
    }
  }
  symbol
}
