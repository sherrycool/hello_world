#' calculate the win ratio of a chosen stocks strategy
#' 
#' @name win ratios
#' @import RODBC
#' @import dplyr
#' @import futile.logger
winratios <- function(date, model, days, zhangfu)
{
  mydb <- odbcConnect(dsn = "caihua")
  model_name <- paste0(model, "_model")
  chosen_list <- eval(call(model_name, date = date))
  symbols <- chosen_list$SYMBOL
  symbols_sql <- paste(symbols, sep = "'", collapse = ",")
  date_end <- date + 10000
  sql_today <- paste0("select SYMBOL,TDATE,TCLOSE,EXCHANGE from CHDQUOTE_ADJ where SYMBOL in (",
                      symbols_sql, ") and TDATE>=", date, " and TDATE<=", date_end,
                      " order by SYMBOL,TDATE")
  raw_data <- sqlQuery(mydb, sql_today)
  raw_data$SYMBOL <- handle_symbols(raw_data$SYMBOL)
  winorlose <- c()
  for (i in 1:length(symbols))
  {
    data_single <- filter(raw_data, SYMBOL == symbols[i])
    if (nrow(data_single) < days)
    {
      flog.error("no sufficient data for %s", symbols[i])
      next
    }
    data_single <- data_single %>% head(days) %>%
      mutate(daily_returns = TCLOSE / TCLOSE[1] - 1)
    if (any(data_single$daily_returns > zhangfu))
    {
      winorlose[i] <- 1
    } else {
      winorlose[i] <- 0
    }
  }
  win_ratio <- sum(winorlose) / length(winorlose)
  return(win_ratio)
}

#' calualate win ratios for a period of time
#' @import RODBC
#' @export
days_win_ratio <- function(date_start, date_end, model, days, zhangfu)
{
  mydb <- odbcConnect(dsn = "caihua")
  sql_days <- paste0("select TDATE from TRADEDATE where TDATE>=", date_start,
                     " and TDATE<=", date_end,
                     " and EXCHANGE in ('CNSESH','CNSESZ') order by TDATE")
  dates <- sqlQuery(mydb, sql_days)
  dates <- unique(dates$TDATE)
  winorlost_table <- data.frame(DATE = NA, WIN_RATIO = NA)
  for (date in dates)
  {
    win_ratio <- winratios(date, model, days, zhangfu)
    data_single <- data.frame(DATE = date, WIN_RATIO = win_ratio)
    print(data_single)
    winorlost_table <- rbind(winorlost_table, data_single)
  }
  winorlost_table <- winorlost_table[-1, ]
  return(list(model = model, winorlost = winorlost_table))
}