#' chose loop for days
#' @name basic symbols
#'
#' @import RODBC
#' @export
tt_chosen <- function(date_start = 20150901, date_end = 20160901, model = "ph",
                      m = 260, w = 5, mm = 20, s = 30, q = 60)
{
  mydb <- odbcConnect(dsn = "caihua")
  sql_days <- paste0("select TDATE from TRADEDATE where TDATE>=", date_start,
                     " and TDATE<=", date_end,
                     " and EXCHANGE in ('CNSESH','CNSESZ') order by TDATE")
  days <- sqlQuery(mydb, sql_days)
  days <- unique(days)
  show_table <- data.frame(TDATE = NA, SYMBOL = NA, TCLOSE = NA, WRATE = NA,
                           MRATE = NA, SRATE = NA, QRATE = NA,
                           WCLOSE = NA, MCLOSE = NA, SCLOSE = NA, QCLOSE = NA)
  symbols_list <- list()
  model_name <- paste0(model, "_chosen")
  for (i in days$TDATE)
  {
    chosen_list <- eval(call(model_name, date = i, m = 260, w = 5, mm = 20,
                             s = 30, q = 60))
    print(chosen_list)
    name <- as.character(i)
    symbols_list[[name]] <- chosen_list
    show_table <- rbind(show_table, chosen_list)
  }
  show_table <- show_table[-1, ]
  return(show_table)
}


#' chose symbols loop for days
#' @name basic symbols
#' @param date_start back start date
#' @import RODBC
#' @export
symbols_chosen <- function(date_start = 20150901, date_end = 20150910, model = "ph")
{
  mydb <- odbcConnect(dsn = "caihua")
  sql_days <- paste0("select TDATE from TRADEDATE where TDATE>=", date_start,
                     " and TDATE<=", date_end,
                     " and EXCHANGE in ('CNSESH','CNSESZ') order by TDATE")
  days <- sqlQuery(mydb, sql_days)
  days <- unique(days)
  show_table <- data.frame(TDATE  = NA, SYMBOL = NA,
                           TCLOSE = NA, EXCHANGE = NA)
  symbols_list <- list()
  model_name <- paste0(model, "_model")
  for (i in days$TDATE)
  {
    chosen_list <- eval(call(model_name, date = i))
    print(chosen_list)
    name <- as.character(i)
    symbols_list[[name]] <- chosen_list
    show_table <- rbind(show_table, chosen_list)
  }
  show_table <- show_table[-1, ]
  return(show_table)
}



#' calculate returns
#' @name calculate returns
chosen_returns <- function(symbols, w = 5, mm = 20, s = 30, q = 60)
{
  mydb <- odbcConnect(dsn = "caihua")
  sql_days <- paste0("select TDATE from TRADEDATE where TDATE>=",
                     date_start, " and TDATE<=", date_end,
                     " and EXCHANGE in ('CNSESH','CNSESZ') order by TDATE")
  days <- sqlQuery(mydb, sql_days)
  days <- unique(days)
  for (i in days)
  {
    chosen_single <- ph_chosen(n = 5, date, m = 260)
    chosen_symbols_sql <- paste(symbols, sep = "'", collapse = ",")
    before_day <- date - 10000
    stop_day <- date + 10000
    sql_today <- paste0("select SYMBOL,TDATE,TCLOSE,EXCHANGE from CHDQUOTE_ADJ
                        where SYMBOL in (", chosen_symbols_sql,
                        ") and TDATE>=", date, " and TDATE<=", stop_day,
                        " order by SYMBOL,TDATE")
    raw_data <- sqlQuery(mydb, sql_today)
  }

  raw_data$SYMBOL <- handle_symbols(raw_data$SYMBOL)
  show_list <- data.frame(TDATE = NA, SYMBOL = NA,	TCLOSE = NA, WRATE = NA,
                          MRATE = NA, SRATE = NA, QRATE = 60, WCLOSE = NA,
                          MCLOSE = NA, SCLOSE = sclose, QCLOSE = qclose)
  for (i in chosen_symbols)
  {
    data_single <- filter(raw_data, SYMBOL == i)
    if (nrow(data_single) < 60 | !(any(data_single$TDATE == date)))
    {
      next
    }
    data_single <- arrange(data_single, TDATE)
    data_single$mean_60 <- SMA(data_single$TCLOSE, 60)
    if (is.na(data_single$mean_60[which(data_single$TDATE == date)]))
    {
      next
    }
    if (data_single$TCLOSE[which(data_single$TDATE == date)] >
        data_single$mean_60[which(data_single$TDATE == date)])
    {
      tlcose <- NA; wclose <- NA; mclose <- NA; sclose <- NA; qclose <- NA
      wrate <- NA; mrate <- NA; srate <- NA; qrate <- NA
      tclose <- data_single$TCLOSE[which(data_single$TDATE == date)]
      wclose <- data_single$TCLOSE[which(data_single$TDATE == date) + w - 1]
      mclose <- data_single$TCLOSE[which(data_single$TDATE == date) + mm - 1]
      sclose <- data_single$TCLOSE[which(data_single$TDATE == date) + s - 1]
      qclose <- data_single$TCLOSE[which(data_single$TDATE == date) + q - 1]
      wrate <- wclose / tclose - 1
      mrate <- mclose / tclose - 1
      srate <- sclose / tclose - 1
      qrate <- qclose / tclose - 1
      show_single <- data.frame(TDATE  = date, SYMBOL = i, TCLOSE = tclose,
                                WRATE = wrate, MRATE = mrate, SRATE = srate,
                                QRATE = qrate, WCLOSE = wclose,	MCLOSE = mclose,
                                SCLOSE = sclose, QCLOSE = qclose)
      show_list <- rbind(show_list, show_single)
    }
  }
  show_list <- show_list[-1, ]
  return(show_list)
}
