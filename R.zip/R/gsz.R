#' choose : gsz
#'
#' 高送转潜力选股策略
#' @name stock dividend chosen
#' @param date operating date
#' @param m time period (year)
#' @return 选出来的股票
#' @export
#' @import RODBC
#' @import dplyr
#' @import purrr
#' @import TTR
gsz_chosen <- function(date = 20160901, m = 2, w = 5, mm = 20, s = 30, q = 60)
{
  symbols_raw <- get_symbols_choose()
  mydb <- odbcConnect(dsn = "caihua")
  # 公司和代码对应表
  sql_3 <- paste0("select SYMBOL,COMPANYCODE from SECURITYCODE where STYPE in ('EQA','EQB')")
  data_3 <- sqlQuery(mydb, sql_3)
  data3 <- unique(data_3)
  data3$SYMBOL <- handle_symbols(data3$SYMBOL)
  # 第一个条件：去年年度和今年中期（近2年内）未实施过送股或转股；
  # 第二个条件：总股本在5亿股以下的上市公司
  # 数据准备
  start_date <- date - m * 10000
  sql_1 <- paste0("select COMPANYCODE,PUBLISHDATE,SCSTC1 as share,SCSTC34 as divident from SCSTC where PUBLISHDATE>=",
                  start_date, " and PUBLISHDATE<=", date, " order by COMPANYCODE,PUBLISHDATE desc")
  data_1 <- sqlQuery(mydb, sql_1)
  # 去重
  data1 <- unique(data_1)
  table_1 <- merge(data3, data1, by='COMPANYCODE', all.x = TRUE)

  # 第一个条件筛选
  table1 <- na.omit(table_1)
  symbols_no <- table1$SYMBOL
  symbols_1 <- setdiff(symbols_raw, symbols_no)
  # 第二个条件筛选
  table2 <- select(table_1, SYMBOL, PUBLISHDATE, share)
  table2 <- na.omit(table2)
  table2 <- arrange(table2, SYMBOL, desc(PUBLISHDATE))
  # 最近的总股本
  table2 <- table2[!duplicated(table2$SYMBOL), ]
  table2 <- filter(table2, share < 50000)
  symbols_2 <- table2$SYMBOL
  # 第3-4个条件：
  # 3. 前三季度实现盈利或年度预盈
  # 4. 同时以下三个条件需满足其一：
  # - 每股资本公积金大于等于5元
  # - 每股未分配利润大于等于4元
  # - 三季度每股资本公积金与未分配利润之和大于8元
  # 数据准备
  start_date_2 <- date - 1 * 10000
  sql_2 <- paste0("select COMPANYCODE,REPORTDATE,FINANCIALRATIOS28 as nProfitRatio,FINANCIALRATIOS63 as csps,FINANCIALRATIOS66 as rdps, FINANCIALRATIOS63+FINANCIALRATIOS66 as thirdCondi from FINANCIALRATIOS where REPORTDATE>=",
                  start_date_2, " and REPORTDATE<=", date, " order by COMPANYCODE")
  data_2 <- sqlQuery(mydb, sql_2)
  data2 <- unique(data_2)
  table_3 <- merge(data3, data2, by = "COMPANYCODE", all.x = TRUE)
  # filter
  table3 <- na.omit(table_3)
  table3 <- arrange(table3, SYMBOL, desc(REPORTDATE))
  table3 <- table3[!(duplicated(table3$SYMBOL)), ]
  table3 <- filter(table3, nProfitRatio > 0 & (csps >= 5 | rdps >= 4 | thirdCondi >= 8))
  symbols_3 <- table3$SYMBOL
  # intersect conditions
  chosen_symbols <- intersect(symbols_1, symbols_2)
  chosen_symbols <- intersect(chosen_symbols, symbols_3)
  chosen_symbols <- unique(chosen_symbols)
  # 第5个条件：收盘价大于60日均线
  chosen_symbols_part1 <- paste0("'", chosen_symbols)
  chosen_symbols_part2 <- paste0(chosen_symbols_part1[1:(length(chosen_symbols) - 1)], "',")
  chosen_symbols_part3 <- reduce(chosen_symbols_part2, paste)
  chosen_symbols_part4 <- chosen_symbols[length(chosen_symbols)]
  chosen_symbols_part4 <- paste0("'", chosen_symbols_part4, "'")
  chosen_symbols_sql <- paste0(chosen_symbols_part3, chosen_symbols_part4, collapse = " ,")
  before_day <- date - 10000
  stop_day <- date + 10000
  sql_today <- paste0("select SYMBOL,TDATE,TCLOSE,EXCHANGE from CHDQUOTE_ADJ where SYMBOL in (", chosen_symbols_sql,
                      ") and TDATE>=", before_day, " and TDATE<=", stop_day," order by SYMBOL,TDATE")
  raw_data <- sqlQuery(mydb, sql_today)
  raw_data$SYMBOL <- handle_symbols(raw_data$SYMBOL)
  show_list <- data.frame(TDATE  = NA, SYMBOL = NA,	TCLOSE = NA, WRATE = NA, MRATE = NA, SRATE = NA, QRATE = 60, WCLOSE = NA,	MCLOSE = NA, SCLOSE = NA, QCLOSE = NA)
  for (i in chosen_symbols)
  {
    data_single <- filter(raw_data, SYMBOL == i)
    if (nrow(data_single) < 60 | !(any(data_single$TDATE == date)))
    {
      next
    }
    data_single <- arrange(data_single, TDATE)
    data_single$mean_60 <- SMA(data_single$TCLOSE, 60)
    if (is.na(data_single$mean_60[which(data_single$TDATE == date)]))
    {
      next
    }
    if (data_single$TCLOSE[which(data_single$TDATE == date)] > data_single$mean_60[which(data_single$TDATE == date)])
    {
      tlcose <- NA; wclose <- NA; mclose <- NA; sclose <- NA; qclose <- NA
      wrate <- NA; mrate <- NA; srate <- NA; qrate <- NA
      tclose <- data_single$TCLOSE[which(data_single$TDATE == date)]
      wclose <- data_single$TCLOSE[which(data_single$TDATE == date) + w - 1]
      mclose <- data_single$TCLOSE[which(data_single$TDATE == date) + mm - 1]
      sclose <- data_single$TCLOSE[which(data_single$TDATE == date) + s - 1]
      qclose <- data_single$TCLOSE[which(data_single$TDATE == date) + q - 1]
      wrate <- wclose / tclose - 1
      mrate <- mclose / tclose - 1
      srate <- sclose / tclose - 1
      qrate <- qclose / tclose - 1
      show_single <- data.frame(TDATE = date, SYMBOL = i, TCLOSE = tclose, WRATE = wrate, MRATE = mrate, SRATE = srate, QRATE = qrate, WCLOSE = wclose, MCLOSE = mclose, SCLOSE = sclose, QCLOSE = qclose)
      show_list <- rbind(show_list, show_single)
    }
  }
  show_list <- show_list[-1, ]
  return(show_list)
}


#' handle the symbol to be XXXXXX character
#'
#' @name handle symbols
#' @param symbols vector
#' @return symbols characterS
handle_symbols <- function(symbols)
{
  for (i in 1:length(symbols))
  {
    if(nchar(symbols[i] < 6))
    {
      while(nchar(symbols[i]) < 6)
      {
        symbols[i] <- paste0('0', symbols[i])
      }
    }
  }
  symbols
}

#' get symbols active after 20160101
#' @import RODBC
get_symbols_choose <- function()
{
  mydb <- odbcConnect(dsn = 'caihua')
  sql <- "SELECT DISTINCT SYMBOL FROM CHDQUOTE_ADJ WHERE TDATE >= 20160101"
  symbol_raw <- sqlQuery(mydb, sql)

  symbol <- as.character(symbol_raw[[1]])

  for (i in 1:length(symbol))
  {
    if(nchar(symbol[i] < 6))
    {
      while(nchar(symbol[i]) < 6)
      {
        symbol[i] <- paste0('0', symbol[i])
      }
    }
  }
  symbol
}
