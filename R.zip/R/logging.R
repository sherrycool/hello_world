
http_log_appender <- function(msg) {
  url <- "http://dam.jinchongzi.com/dam/v1/tsdb/write"
  series = paste0("stra.", strsplit(par_stra("__strategy_id", "development"), "/")[[1]][1])
  level <- get("level", parent.frame())
  data <- data.frame(time=as.numeric(Sys.time()),series=series)
  data$tags <- data.frame(level=names(level), pid=Sys.getpid(), lang="R")
  data$values=data.frame(msg=msg)

  post = list(db='logging', points=data)
  body <- jsonlite::toJSON(post, auto_unbox=TRUE)
  h <- basicTextGatherer()
  RCurl::curlPerform(url = url,
                     httpheader=c(
                       "Accept" = "text/*",
                       "Accept" = "multipart/*",
                       "Content-Type" = "application/json; charset=utf-8"),
                     postfields=body,
                     writefunction = h$update,
                     verbose = TRUE)
  result <- h$value()
}
