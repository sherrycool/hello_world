##' TODO: import IRdisplay
#NULL

#' @export
GLOBAL_UCID <- 0

#' emit an startegy event
#' @export emit_event output.emit_event
#' @param event_type event type
#' @param payload the payload data
#' @param ucid user context id
#' @param source_id source id
#' @param globally if TRUE, emit a global event, else emit an event in current user context
#' @aliases output.emit_event
emit_event_old <- function(event_type, payload, ucid=NULL, source_id=NULL, globally=FALSE) {
  if (is.null(ucid)) {
    ucid <- ifelse(globally, GLOBAL_UCID, par.stra("__ucid", GLOBAL_UCID))
  }
  sid <- par.stra("__strategy_id", "unkown")
  callback_url <- par.stra("__callback_url")
  wrapped_data <- list(
    type = "event",
    strategy_id = sid,
    event = event_type,
    ucid = ucid,
    source_id = source_id,
    payload = payload
  )
  if (!is.null(callback_url)) {
    wrapped_data$callback_url <- callback_url
    wrapped_data$type <- "strategy_output"
  }
  if (is_qbt()) {
    IRdisplay:::display_json(jsonlite::toJSON(wrapped_data, auto_unbox = TRUE))
  } else {
    print(jsonlite::toJSON(wrapped_data, auto_unbox = TRUE, pretty = T)) # TODO
  }
}

emit_event <- function(event_type, payload, ucid=NULL, source_id=NULL, globally=FALSE, debug=FALSE) {
  if (is.null(ucid)) {
    ucid <- par.stra("__ucid", GLOBAL_UCID)
  }
  wrapped_data <- list(
    type = event_type,
    source_id = source_id,
    payload = payload
  )
  if (is_qbt()) {
    role <- Sys.getenv("ROLE")
    qbt_base_url_config <- get_config(ifelse(role == "backtest", "QBT_BT_BASE_URL", "QBT_BASE_URL"));
    if (role == "backtest") {
        qbt_base_url <- par.stra("__backtest_host", qbt_base_url_config)
    } else {
        qbt_base_url <- qbt_base_url_config
    }
    if (is.null(ucid) || globally) {
      qbt_url <- paste0(qbt_base_url, "/apiv1/user_context/emit_event");
    } else {
      qbt_url <- paste0(qbt_base_url, "/apiv1/user_context/emit_event/", ucid);
    }

    body <- jsonlite::toJSON(wrapped_data, auto_unbox = TRUE)
    h <- basicTextGatherer()
    RCurl::curlPerform(url = qbt_url,
                       httpheader = c(
                         "Accept" = "text/*",
                         "Accept" = "multipart/*",
                         "Content-Type" = "application/json; charset=utf-8"),
                       postfields = body,
                       writefunction = h$update,
                       verbose = TRUE)
    result <- h$value()
    (jsonlite::fromJSON(result))$data
  } else {
    if(debug) print(jsonlite::toJSON(wrapped_data, auto_unbox = TRUE, pretty = T)) # TODO
  }
}

output.emit_event <- emit_event


#' @export done Return .return return_ output.done control.done control.return
#' @aliases Return .return return_ output.done control.done control.return
done <- function(data) {
  sid <- par.stra("__strategy_id", "unkown")
  ucid <- par.stra("__ucid")
  wrapped_data <- list(
    type = "done",
    strategy_id = sid,
    ucid = ucid,
    data = data
  )
  if (is_qbt()) {
    IRdisplay:::display_json(jsonlite::toJSON(wrapped_data, auto_unbox = TRUE))
  } else {
    print(jsonlite::toJSON(wrapped_data, auto_unbox = TRUE, pretty = T)) # TODO
  }
}
Return <- .return <- return_ <- done
output.done <- done
control.return <- control.done <- output.done


#' strategy output
output_strategy <- function(entry, data, output_type, display_type=NULL) {
  sid <- par.stra("__strategy_id", "unkown")
  callback_url <- par.stra("__callback_url")
  ucid <- par.stra("__ucid")
  wrapped_data <- list(
    type = "strategy_output",
    strategy_id = sid,
    callback_url = callback_url,
    ucid = ucid,
    entry = entry,
    output_type = output_type,
    display_type = display_type,
    data = data
  )
  if (is.web()) {
    IRdisplay:::display_json(jsonlite::toJSON(wrapped_data, auto_unbox = TRUE))
  } else {
    print(jsonlite::toJSON(wrapped_data, auto_unbox = TRUE, pretty = T)) # TODO
  }
}


#' @export output_misc output.misc
#' @aliases output.misc
output_misc <- function(data) {
  output_strategy("misc", data, "misc")
}
output.misc <- output_misc


#' @export output_screen output.screen
#' @aliases output.screen
output_screen <- function(stocks) {
  output_strategy("screen", stocks, "stocks")
}
output.screen <- output_screen


#' @export output_timing output.timing
#' @aliases output.timing
output_timing <- function(time, signal) {
  output_strategy("timing", list(time = time, signal = signal), "signal")
}
output.timing <- output_timing


#' @export output_trading  output.trading
#' @aliases output.trading
output_trading <- function(data, output_type) {
  output_strategy("trading", data, output_type)
}
output.trading <- output_trading


#' @export output_backtest output.backtest
#' @aliases output.backtest
output_backtest <- function(data, output_type, display_type=NULL) {
  output_strategy("backtest", data, output_type, display_type)
}
output.backtest <- output_backtest


#' @export output_backtest_accum output.backtest.accum
#' @aliases output.backtest.accum
output_backtest_accum <- function(times, data) {
  data <- matrix(c(times, data), ncol=2)
  output_backtest(data, "accum", "chart")
}
output.backtest.accum <- output_backtest_accum


#' @export output_backtest_daily output.backtest.daily
#' @aliases output.backtest.daily
output_backtest_daily <- function(times, data) {
  data <- matrix(c(times, data), ncol=2)
  output_backtest(data, "daily", "chart")
}
output.backtest.daily <- output_backtest_daily


#' @export output_backtest_drawdowns output.backtest.drawdowns
#' @aliases output.backtest.drawdowns
output_backtest_drawdowns <- function(times, data) {
  data <- matrix(c(times, data), ncol=2)
  output_backtest(data, "drawdowns", "chart")
}
output.backtest.drawdowns <- output_backtest_drawdowns


#' @export output_backtest_misc output.backtest.misc
#' @aliases output.backtest.misc
output_backtest_misc <- function(data) {
  output_backtest(data, "misc", NULL)
}
output.backtest.misc <- output_backtest_misc
