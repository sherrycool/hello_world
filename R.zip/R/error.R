#' 统一错误处理
#'
#' @param error_code type string, e.g.: "E1", "E2", "E3", ...  必填。
#' @param ...  送错误提示相关的信息
#'
#' @return error 对象，值为False，对象具有属性erro_code和error_info
#' @export
#' @examples
#' j.error("E1", "symbol = 600030")
#' j.error("E1")
#' attr(j.error("E1"), "error_info") 获取错误信息
#' return(j.error("E1"))  返回False，并将错误代码和错误信息一并返回
#'
j.error <- function(error_code, ...)
{
  error_info <- sprintf(get_error_info(error_code), ...)

  flog.error(error_info)

  f <- F
  attr(f, "error_code") <- error_code
  attr(f, "error_info") <- error_info
  return(f)
}

#' 错误代码表
#'
#' @param error_code
#'
get_error_info <- function(error_code){

    E1 <- "获取数据错误！%s"
    E2 <- "股票 %s 数据不足以完成计算! 需要开始时间：%s,  实际开始时间: %s。"
    E3 <- "执行策略错误！策略名称：%s， 股票名称：%s。"
    E4 <- "证券代码格式错误： %s。"

  return(get(error_code))
}