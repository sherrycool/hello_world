#' Lint all R source files under a directory
#' @export
#' @param path directory to lint
#' @param exit_on_error exit with a non-zero code if an error occurs
slint <- function(path=".", exit_on_error=FALSE) {
  options(encoding="UTF-8");
  file_info <- file.info(path);
  if (is.na(file_info$isdir)) {
    return();
  }
  if (file_info$isdir) {
    files <- list.files(path=path, recursive=TRUE, pattern=".*\\.[rR]$", full.names=TRUE);
  } else {
    files <- c(path);
  }
  linters <- lintr:::with_defaults(object_usage_linter=NULL,
                                   open_curly_linter=NULL,
                                   line_length_linter=lintr:::line_length_linter(100),
                                   object_length_linter=lintr:::object_length_linter(42),
                                   commented_code_linter = NULL,
                                   camel_case_linter=NULL,
                                   snake_case_linter=NULL);
  exit_status <- 0;
  output <- lapply(files,
                   function(file) {
                     if (interactive() || isatty(stdout())) {
                       message(paste("linting file: ", file), appendLF = TRUE);
                     }
                     lint_info <- lintr:::lint(file, linters, parse_settings = FALSE);
                     if (length(lint_info) > 0) {
                       print(lint_info);
                       exit_status <<- 120;
                       if (exit_on_error) {
                         q(save = "default", status = exit_status);
                       }
                     }
                   });

  message("", appendLF=FALSE);
  if (!interactive()) {
    q(save = "default", status = exit_status);
  }
}
