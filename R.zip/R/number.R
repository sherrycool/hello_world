#########################################################################################
#' 函数功能：检查输入数据是否是正数
#'
#' @param num --输入数据
#' @param isZero  如果为真则视0为正数
#'
#' @return TRUE if the input number is positive, else FALSE
#' @export is_positive_num isPossiNum
#' @aliases isPossiNum
#' @examples
#' is_positive_num(1)
#' is_positive_num(0, TRUE)
#' is_positive_num(-1)
is_positive_num <- function(num, isZero=FALSE)
{
  if (!is.numeric(num)) return(FALSE)
  else if(num > 0) return(TRUE)
  else if(num == 0 & isZero) return(TRUE)
  else return(FALSE)
}
isPossiNum <- is_positive_num


#' 检查输入数据是否是正整数
#'
#' @param num 输入数据
#' @param isZero  如果为真则视0为正数
#'
#' @return TRUE if the input number is positive integer, else FALSE
#' @export is_positive_int isPossiInt
#' @aliases isPossiInt
#' @examples
#' is_positive_int(1)
#' is_positive_int(0, TRUE)
#' is_positive_int(-1)
is_positive_int <- function(num, isZero=FALSE)
{
  if(!is.numeric(num)) return(FALSE)
  else if(num %% 1 != 0) return(FALSE)
  else if(num > 0) return(TRUE)
  else if(num == 0 & isZero) return(TRUE)
  else return(FALSE)
}
isPossiInt <- is_positive_int


#' 检查输入数据是否是在给定范围之内
#'
#' @param num
#' @param lower_bound 下界
#' @param upper_bound 上界
#'
#' @return TRUE if the input number is within the range, else FALSE
#' @export within_range withinRange
#' @aliases withinRange
#' @examples
#' within_range(2,1,3)
#' within_range(2.4,1,3.1)
within_range <- function(num, lower_bound, upper_bound)
{
  if(!is.numeric(num)) return(FALSE)
  else if(num >= lower_bound & num <= upper_bound) return(TRUE)
  else return(FALSE)
}
withinRange <- within_range
