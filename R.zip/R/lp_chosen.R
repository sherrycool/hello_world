#' choose : lp
#' @name lp
#' @param n 选多少只股票( <100)
#' @param date operating date
#' @return 选出来的股票
#' @import RODBC
#' @import dplyr
#' @export
lp_chosen <- function(n, date)
{
  # 获取数据
  mydb <- odbcConnect(dsn = "caihua")
  bn_day <- as.integer(as.character(format(as.Date(as.character(date), format = "%Y%m%d") - 30, "%Y%m%d")))
  sql <- paste("SELECT SYMBOL, TDATE, PE, TCLOSE FROM DERFQUOTE WHERE TDATE>=",
               bn_day, " AND TDATE<=", date, " order by SYMBOL,TDATE desc", sep = "")
  row_data <- sqlQuery(mydb, sql)
  row_data$SYMBOL <- handle_symbols(row_data$SYMBOL) 
  raw_data <- tbl_df(row_data)
  min_n_table <-   raw_data %>%
    group_by_(SYMBOL) %>%
    summarise(min_pe = count(TDATE)) %>%
    arrange(desc(min_pe)) %>%
    head(5)
  
  
  date_symbol <- raw_data %>%
    group_by(SYMBOL) %>%
    summarise(max_date = max(TDATE))
  
  need_data <- filter(raw_data, TDATE )
  
  need_data <- merge(date_symbol, row_data, by = intersect("SYMBOL","TDATE"), all.x = TRUE, all.y = FALSE)
  symbols <- min_n_table$SYMBOL

}


#' handle the symbol to be XXXXXX character
#'
#' @name handle symbols
#' @param symbols vector
#' @return symbols character
#' @export
handle_symbols <- function(symbols)
{
  for (i in 1:length(symbols))
  {
    if(nchar(symbols[i] < 6))
    {
      while(nchar(symbols[i]) < 6)
      {
        symbols[i] <- paste0('0', symbols[i])
      }
    }
  }
  symbols
}

