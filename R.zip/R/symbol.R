#' guess exchange name by stock symbol
#'
#' @param symbol stock symbol
#' @return "CNSESZ", "CNSESH", or ""
#' @export get_exchange_by_symbol get_exchange_from_symbol
#' @aliases get_exchange_from_symbol
#' @examples
#' get_exchange_by_symbol("000567")
get_exchange_by_symbol <- function(symbol)
{
  SZ_REGEX <- c("(^(000|001|002)(\\d{3}))|(^(30)(\\d{4}))",
                "^(03|28|38)(\\d{4})",
                "^(07|08|37)(\\d{4})",
                "^(100|101)(\\d{3})",
                "(^(108|109|111|112|115)(\\d{3}))|(^(12)(\\d{4}))",
                "^(13)(\\d{4})",
                "^(18)(\\d{4})",
                "^(15|16)(\\d{4})",
                "^(20)(\\d{4})",
                "^(39)(\\d{4})")
  SH_REGEX <- c("^(000)(\\d{3})",
                "(^(009)(\\d{3}))|(^(010|090|099)(\\d{3}))",
                "^(100|110|112|113|120|121|126|129|181|190|191)(\\d{3})",
                "^(20)(\\d{4})",
                "^(310)(\\d{3})",
                "^(500)(\\d{3})",
                "^(510|519|521|522|523|524)(\\d{3})",
                "^(580|582)(\\d{3})",
                "^(600|601|603)(\\d{3})",
                "^(700|702|704|705|706|730|731|733|735|738|740|741|743|744|745|
                746|751|760|762|764|780|781|783|788|790|791|793|794|799)(\\d{3})",
                "^(900|938|939)(\\d{3})")

  for (reg in SZ_REGEX)
  {
    if (!is.na(str_match(symbol, reg)[1, 1])) return("CNSESZ")
  }
  for (reg in SH_REGEX)
  {
    if (!is.na(str_match(symbol, reg)[1, 1])) return("CNSESH")
  }
  return("")
}
get_exchange_from_symbol <- get_exchange_by_symbol


#' 函数功能：将int类型的stocks数组变成六位的character类型数组
#'
#' @param data stocks--int类型的stocks数组
#' @return data which SYMBOL attribute has changed to six-bit character
#' @export data_to_character dataToCharacter
#' @aliases dataToCharacter
#' @examples
#' data_to_character(data)
data_to_character <- function(data)
{
  if (!is.null(data$SYMBOL))
  {
    data$SYMBOL <- to_character(data$SYMBOL)
  }
  return(data)
}
dataToCharacter <- data_to_character



#' Check whether the nday equals to the num of the stock data except the suspended data
#'
#' @param stock_data stock data
#' @param start the begin date
#' @param end the end date
#' @param nday compared day num
#' @return TRUE if equals, else FALSE
#' @export is_valid_stock isValidStock
#' @aliases isValidStock
#' @examples
#' is_valid_stock(stock_data, 20160411, 20160415, 5)
is_valid_stock <- function(stock_data, start, end, nday)
{
  data_select <- stock_data[stock_data$TDATE >= start &
                              stock_data$TDATE <= end &
                              stock_data$TCLOSE != 0, ]
  if (nrow(data_select) == nday)
  {
    return(TRUE)
  }
  else
  {
    return(FALSE)
  }
}
isValidStock <- is_valid_stock


#' Return stock symbols of the specified day and exchange symbol
#'
#' @param rowData the stock data
#' @param day specified date
#' @param exchange specified exchange symbol
#' @return stock symbols selected
#' @export fetch_stock_names fetchStockNames
#' @aliases fetchStockNames
#' @examples
#' fetch_stock_names(rowData, 20160415, "CNSESH")
fetch_stock_names <- function(rowData, day, exchange)
{
  stocks <- rowData[rowData$TDATE == day & rowData$EXCHANGE == exchange, "SYMBOL"]
  stocks <- to_character(stocks)
  return(stocks)
}
fetchStockNames <- fetch_stock_names



#' 检查某symbol字符串是否规范化，如果不规范则尝试规范化
#'
#' @param symbol 证券字符串，支持"^QUOTE.[[:digit:]]{6}.CHSES[HZ]$"、"^[[:digit:]]{6}.CNSES[HZ]$"、“[[:digit:]]{6}”这几种格式
#'
#' @return 返回格式化好的symbol或者false
#' @export
#'
#' @examples
#' symbol_check_and_format("000001")
#' symbol_check_and_format("000001.CNSESH")
#' symbol_check_and_format("QUOTE.000001.CNSESH")
symbol_check_and_format <- function(symbol){
  check <- grep("^[[:digit:]]{6}$", symbol)
  if(!is.null(check) && length(check) == 1 && !is.na(check) && check == 1)
  {
    ## try to guess a symbol's exchange
    symbol <- paste("QUOTE", symbol, get_exchange_by_symbol(symbol), sep=".")
  }
  check <- grep("^[[:digit:]]{6}.CNSES[HZ]$", symbol)
  if(!is.null(check) && length(check) == 1 && !is.na(check) && check == 1)
  {
    ## try to guess a symbol's exchange
    symbol <- paste("QUOTE", symbol, sep=".")
  }
  check <- grep("^QUOTE.[[:digit:]]{6}.CNSES[HZ]$", symbol)
  if(!is.null(check) && length(check) == 1 && !is.na(check) && check == 1)
  {
    return(symbol)
  }
  else
  {
    return(FALSE)
  }
}