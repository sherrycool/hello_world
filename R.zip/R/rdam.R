#' 从dam取数据函数
#'
#' @param db wsd,wsi,wst,wss,wsq,wset,weqs,wpf, tdays，分类见万德开放接口
#' @param symbol  送单只股票的代码，如"QUOTE.600656.CNSESH"
#' @param where e.g. start=20160901&stop=20161001&order=asc&limit=1000&aggregate=count&group=*
#' @param cols
#' @param dam_url dam服务器的基础url
#' @param verbose
#'
#' @return 行情列表
#' @examples
#' http://mysql00.chong.so:8085/dam/v1/tsdb/q?db=caihua&series=QUOTE.600656.CNSESH&limit=10
#' j.get("wsd", "QUOTE.600656.CNSESH", "start=20160901&stop=20161001&order=asc&limit=1000&aggregate=count&group=*", "TOPEN")
#
j.get <- function(db,
                  symbol,
                  where = "",
                  cols = "TDATE,EXCHANGE,LCLOSE,TOPEN,TCLOSE,HIGH,LOW,TURNOVER,VATURNOVER,VOTURNOVER",
                  verbose = F,
                  dam_url = "http://mysql00.chong.so:8085/dam/v1/tsdb/q")
{

  db <- switch(db,
               wsd = "caihua",
               tdays = "caihua",
               "caihua")

  url <- sprintf("%s?db=%s&series=%s%s", dam_url, db, symbol, where)

  h <- basicTextGatherer()
  RCurl::curlPerform(url = url,
                     httpheader = c(
                       "Accept" = "text/*",
                       "Accept" = "multipart/*",
                       "Content-Type" = "application/json; charset=utf-8"),
                     writefunction = h$update,
                     verbose = verbose)
  result   <- h$value()

  row_data <- jsonlite::fromJSON(result)$points$values
  if (is.null(row_data))
  {
    return(NULL)
  }

  columns  <- c(unlist(strsplit(cols, ",")))
  return(row_data[columns])
}


#' j.wsd 获取历史序列数据, like w.wsd
#'
#' @param series 字符串, 用逗号隔开的股票代码，如: "600030,600031"，或"600030.CNSESH"，注意交易所编码遵循财华的
#' @param cols 需要返回的字段列表，注意TDATE缺省返回，不需要写。如："TCLOSE,TOPEN,LOW"
#' @param start_date 回测开始日期
#' @param stop_date 结束日期
#' @param lead_rows 能够回测所需的前导数据行数
#' @param verbose 详细日志开关
#' @param cache 是否使用缓存开关，
#'              如果打开则先在本地缓存中查找数据，如果本地没有才到服务器取，如果关上则直接去服务器取。
#'              缺省为F
#'
#' @export
#' @return 返回获取到的数据data.frame，其中一定有TDATE，加上cols中定义的列，并按照TDATE升序排列
#'          返回的dataframe的列命名将采取symbol+colname的方式，以便支持多值symbol。
#'          如入参series = "600000.CNSESH,600030", cols="TCLOSE"，则返回的列名为600000.CNSESH.TCLOSE和600030.TCLOSE
#' @examples
#'  row_data<-j.wsd("600000.CNSESH","TCLOSE,TOPEN",20130430,20150101)
#'  row_data<-j.wsd("600000.CNSESZ","TCLOSE,TOPEN",20130430,20150101)
#'
#' @references
#' 参数请参见：https://jcz.quip.com/JKbJAFEFzff4
#' \itemize{
#'  \item { 管理到dam的链接，url}
#'  \item { 模仿万德接口，类型定义如下 }
#'  \item { j.asDateTime: 把数字化时间格式转换成R语言时间格式 }
#'  \item { j.wsd：获取历史序列数据 }
#'  \item { j.wsi：获取分钟数据 }
#'  \item { j.wst：获取日内tick级别数据 }
#'  \item { j.wss：获历史截面数据 }
#'  \item { j.wsq：获取和订阅实时行情数据 }
#'  \item { j.wset：获取板块、指数等成分数据 }
#'  \item { j.weqs：获取条件选股结果 }
#'  \item { j.wpf：获取资产管理、组合管理数据 }
#'  \item { j.tdays：交易日历相关数据 }
#'  \item { \href{http://www.dajiangzhang.com/document#pointa_70650dc9-f379-43b5-a8e5-bf42f1035c2d }{ 大奖章开发接口参考 }
#'        }
#' }
#'
j.wsd <- function(series, cols, start_date, stop_date, lead_rows = 1, verbose = F, cache = F)
{
  if(is.null(start_date) ||
     start_date == "")
  {
    start_date <- 19000101  ##如果没有设置start_date，则从头取数据
  }

  cols <- paste0("TDATE,", cols)
  where <- sprintf("&stop=%s", stop_date) ##只输入stop，以便后面处理limit和order

  ## 将日期估算成行数
  data_rows <- estimated_rows(start_date, stop_date, lead_rows)

  where <- sprintf("%s&limit=%s&order=DESC", where, data_rows)  ## 必须增加&order=DESC


  result <- c()
  for (symbol in unlist(strsplit(series, ",")))
  {
    symbol_of_dam <- symbol_check_and_format(symbol)
    if(symbol_of_dam == FALSE)
    {
      j.error("E4", symbol)
      next
    }

    temp <- data.frame()

    ##如果有缓存，则从缓存中取并更新缓存
    key <- paste0("wsd", symbol_of_dam, cols)  ##key = category+symbol_of_dam+cols
    if (cache && is_cached(key))
    {
      cache_data <- stralib::get_cache(key)
      if (!is.null(cache_data) &
          start_date >= attr(cache_data, "start_date") &  ##判断是否日期全部命中
          stop_date <= attr(cache_data, "stop_date") &
          lead_rows <= attr(cache_data, "lead_rows"))
      {
        return(cache_data)
      }
    }

    temp <- j.get("wsd", symbol_of_dam, where, cols, verbose)

    if (is.null(temp))
    {
      return(NULL)
    }
    else
    {
      ## 将除TDATE之外的column名标记上symbol，以免无法merge
      columns  <- c(unlist(strsplit(cols, ",")))
      if(length(columns) > 1 && columns[1] == "TDATE"){
        colnames(temp) <- c(columns[1],  ## assume to "TDATE"
                                paste(symbol, columns[2:length(columns)], sep = "."))
      }

      temp <- temp[order(temp[, "TDATE"], decreasing = F), ]

      ##写缓存
      attr(temp, "start_date") <- start_date
      attr(temp, "stop_date") <-  stop_date
      attr(temp, "lead_rows") <-  lead_rows
      stralib::set_cache(key, temp)
    }

    if (is.null(result))
    {
      result <- temp
    }
    else
    {
      result <- merge(result, temp)
    }
  }

  return(result)
}


#' 取交易日历数据
#'
#' @param exchange 交易所编码（caihua），一次送一个交易所，如：CNSESH
#' @param start_date 开始日期, 可选，缺省为所有
#' @param stop_date 结束日期, 可选，缺省为所有。如有daycounts参数，则stop_date失效
#' @param daycounts 如果送daycounts，大于0则以start_date为开头往后取daycounts天，小于0则向前取daycounts天，等于0失效
#'                  注意count时把start_date也算在内，如果start_date不是tradeday，则会从下一个交易日开始count
#'                  如果start_date是tradeday，则会start_date开始count
#' @param verbose 是否打印debug，可选，缺省为F
#' @param cache 是否缓存，可选，缺省为F
#'
#' @return 所有的tdate列
#' @export
#'
#' @examples
#'   se_sh <- j.tdays("CNSESH")
#'   se_sh <- j.tdays("CNSESH", 20160101)
#'   se_sh <- j.tdays("CNSESH", 20160101, 20160201)
#'   se_sh <- j.tdays("CNSESH", stop_date = 20160201)
#'   se_sh <- j.tdays("CNSESH", start_date = 20160201, daycounts = 1)
#'   se_sh <- j.tdays("CNSESH", start_date = 20160201, daycounts = 20)
#'   se_sh <- j.tdays("CNSESH", start_date = 20160201, daycounts = -1)
#'   se_sh <- j.tdays("CNSESH", start_date = 20160201, daycounts = -2)
#'   se_sh <- j.tdays("CNSESH", start_date = 20160201, daycounts = -1000)
j.tdays <- function(exchange, start_date = NULL, stop_date = NULL, daycounts = NULL, verbose = F, cache = F){

  cols <- "TDATE"

  if(!is.null(exchange))
  {
    exchange <- sprintf("TDATES.%s", exchange)
  }
  else
  {
    return(NULL)
  }

  where <- ""
  if(!is.null(daycounts) && daycounts != 0)
  {
    if(daycounts > 0){
      where <- sprintf("%s&limit=%s&order=ASC", where, daycounts)
      if(!is.null(start_date))
      {
        where <- sprintf("%s&start=%s", where, start_date)
      }
    }
    else
    {
      where <- sprintf("%s&limit=%s&order=DESC", where, abs(daycounts))
      if(!is.null(start_date))
      {
        where <- sprintf("%s&stop=%s", where, start_date)
      }
    }
  }
  else
  {
    if(!is.null(start_date))
    {
      where <- sprintf("%s&start=%s", where, start_date)
    }
    if(!is.null(stop_date) && is.null(daycounts))
    {
      where <- sprintf("%s&stop=%s", where, stop_date)
    }
  }

  ##如果有缓存，则从缓存中取并更新缓存
  key <- paste0("tdays", exchange)  ##key = category+symbol+cols
  if (cache && is_cached(key))
  {
    cache_data <- stralib::get_cache(key)
    if (!is.null(cache_data) &&
        start_date >= attr(cache_data, "start_date") &&  ##判断是否日期全部命中
        stop_date <= attr(cache_data, "stop_date"))
    {
      return(cache_data)
    }
  }

  ## 没有缓存从dam取
  result <- j.get("tdays", exchange, where, cols, verbose)

  if (is.null(result))
  {
    return(NULL)
  }
  else
  {
    ##写缓存
    attr(result, "start_date") <- start_date
    attr(result, "stop_date") <-  stop_date
    stralib::set_cache(key, result)
  }

  return(result)
}

#' is_data_ok 判断数据是否满足需求, 目前只支持index指标类策略
#'
#' @param row_data
#' @param symbol
#' @param start
#' @param lead_rows
#' @param cols
#'
#' @return 返回T or F， 如果是F, 则返回一个j.error对象，在属性中保存error_code和error_info，见j.error说明
#'
#' @export
#' @examples
is_data_ok <- function(row_data, symbol, cols, start, lead_rows)
{
  ##把cols拼装成j.wsd的结构 TDATE,symbol.TCLOSE..., etc.
  cols <- c(unlist(strsplit(cols, ",")))
  cols <- paste0(symbol, ".", cols)
  cols <- c("TDATE", cols)

  ##判断取得的数据是否正确可用
  if (is.null(row_data) ||
      colnames(row_data) != cols)
  {
    return(j.error("E1", paste0("symbol=", symbol, "没有数据！")))
  }

  ##判断数据是否够用
  if (max(row_data$TDATE) < start ||
      which(row_data$TDATE >= start)[1] < lead_rows ||  ##向前推行数不足
      nrow(row_data) < lead_rows )
  {
    return(j.error("E2", symbol, start, row_data[1, "TDATE"]))
  }
  return(T)
}

#' estimated_rows 估计需要取得数据行数，算法是以保证取出足够多的数据为原则的，而不是足够少
#'    计算方法是根据start_date和stop_date之间的天数再加上向前推算一个最小行数得到预估的行数
#'
#' @param start_date
#' @param stop_date
#' @param lead_rows
estimated_rows <- function(start_date, stop_date, lead_rows)
{
  start_date <- as.Date(as.character(start_date), "%Y%m%d")
  stop_date  <- as.Date(as.character(stop_date), "%Y%m%d")
  diff_days  <- as.integer(difftime(stop_date, start_date, units = "days"))
  weekends   <- as.integer(difftime(stop_date, start_date, units = "weeks")) * 2
  diff_days - weekends + lead_rows
}
