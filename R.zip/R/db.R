

#' fetch data from mysql with a sql
#'
#' @param sql the sql sentence
#' @param max the minimum
#' @return the required data
#' @export fetch_mysql
#' @import RMySQL
#' @examples
#' fetch_mysql(sql)
#' fetch_mysql(sql ,max = 100)
#'
#' sql <- "SELECT * FROM TRADEDATE where exchange='CNSESH' and TDATE>20160101"
#' row_data <- fetch_mysql(sql)
#'
#' sql <- "SELECT * FROM TRADEDATE where exchange='CNSESH' and TDATE>20160101 order by TDATE desc"
#' max <- 9
#' row_data <- fetch_mysql(sql, max)
fetch_mysql <- function(sql,
                        max = -1,
                        dbname = get_config("CHDB_NAME"),
                        user = get_config("CHDB_USERNAME"),
                        password = get_config("CHDB_PASSWORD"),
                        host = get_config("CHDB_HOST"),
                        port = get_config("CHDB_PORT"),
                        encoding = NULL)
{
  conn <- dbConnect(MySQL(), dbname=dbname, user=user, password=password, host=host, port=port)
  if(is.null(encoding)) {
    if(Sys.getlocale("LC_CTYPE") == "Chinese (Simplified)_China.936") {
      encoding <- "GBK"
    } else {
      encoding <- "UTF8"
    }
  }
  dbSendQuery(conn, paste0("SET NAMES ", encoding))

  suppressWarnings(
    rs <- dbSendQuery(conn, sql)
  )
  dbColumnInfo(rs)
  row_data <- dbFetch(rs, n = max)

  dbClearResult(rs)
  dbDisconnect(conn)

  if(nrow(row_data) != 0)
  {
    return(row_data)
  }
  else
  {
    return(FALSE)
  }
}


#' @export
store <- function(metric, fields, tags=list())
{
  ## qbt_base <- "http://localhost:8888"  # TODO get url from par
  qbt_base <- get_config("QBT_URL")
  url <- paste0(qbt_base, "/apiv1/user_context/store")
  body <- jsonlite::toJSON(list(metric=metric, fields=fields, tags=tags), auto_unbox=TRUE)
  h <- basicTextGatherer()
  RCurl::curlPerform(url = url,
                     httpheader=c(
                       "Accept" = "text/*",
                       "Accept" = "multipart/*",
                       "Content-Type" = "application/json; charset=utf-8"),
                     postfields=body,
                     writefunction = h$update,
                     verbose = TRUE)
  result <- h$value()
  (jsonlite::fromJSON(result))$data
}
