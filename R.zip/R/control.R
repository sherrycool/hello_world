library(bitops)
library(RCurl)
library(jsonlite)

#' @import bitops RCurl jsonlite
NULL

.__sched_calls <- list()


#' schedule a call to anther strategy
#' @param sid id of the callee strategy
#' @param strategy_paras strategy parameters
#' @param entry entry name
#' @param entry_paras entry parameters
#' @return the result
#' @aliases control.sched_call
#' @export sched_scall control.sched_call
#' @examples
#' sched_scall("Example/metadata.yml", NULL, "timing", NULL)
sched_scall <- function(sid,
                        strategy_paras=NULL,
                        entry="main",
                        entry_paras=NULL) {
  call <- list(
    sid=sid,
    strategy_paras=strategy_paras,
    entry=entry,
    entry_paras=entry_paras
  )
  .__sched_calls[[length(.__sched_calls) + 1]] <<- call
}
control.sched_call <- sched_scall


#' call the scheduled strategy calls
#' @export scall control.call
#' @aliases control.call
scall <- function() {
  url <- "http://localhost:8888/apiv1/sched/call"  # TODO get url from par
  body <- jsonlite::toJSON(list(calls=.__sched_calls), auto_unbox=TRUE)
  .__sched_calls <<- list()
  h <- basicTextGatherer()
  RCurl::curlPerform(url = url,
                     httpheader=c(
                       "Accept" = "text/*",
                       "Accept" = "multipart/*",
                       "Content-Type" = "application/json; charset=utf-8"),
                     postfields=body,
                     writefunction = h$update,
                     verbose = TRUE)
  result <- h$value()
  (jsonlite::fromJSON(result))$data
}
control.call <- scall
