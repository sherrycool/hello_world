#' choose : PEG
#'
#' PEG选股策略
#' @name PEG chosen model
#' @param date operating date
#' @param m time period (year)
#' @return 选出来的股票
#' @export
#' @import RODBC
#' @import dplyr
#' @import TTR
peg_model <- function(date = 20160901)
{
  symbols_raw <- get_symbols_choose()
  mydb <- odbcConnect(dsn = "caihua")
  # 公司和代码对应表
  sql_code <- paste0("select SYMBOL,COMPANYCODE from SECURITYCODE where STYPE in ('EQA','EQB')")
  data_code <- sqlQuery(mydb, sql_code)
  data_code <- unique(data_code)
  data_code$SYMBOL <- handle_symbols(data_code$SYMBOL)
  # 第一个条件： PEG < 0.5
  # 第二个条件： 每股收益为正(ERP)
  # 第三个条件： 股价大于60日均线
  # 第四个条件： 连续5个季度净利润同比增长大于50%
  # 数据准备：PE(CIHMQUOTE-today-1) TCLOSE(CHDQUOTE_ADJ-day-60days-60days-3)
  #ERP(CINST59)(CINST-today-lastperiod-1-2) NPR(FinancialRatios44)(FinancialRatios)
  # 第二个条件
  date_start_1 <- date - 1 * 10000
  sql_2 <- paste0("select COMPANYCODE,REPORTDATE,CINST29 as ERP from CINST where REPORTDATE>=",
                  date_start_1, " and REPORTDATE<=", date,
                  " and REPORTSTYLE=11 order by COMPANYCODE,REPORTDATE desc")
  data_2 <- sqlQuery(mydb, sql_2)
  data_2 <- unique(data_2)
  data_2 <- na.omit(data_2)
  data_2 <- merge(data_code, data_2, by = "COMPANYCODE", all.x = TRUE)
  symbols_table_2 <- filter(data_2, ERP > 0)
  symbols_2 <- symbols_table_2$SYMBOL
  # 第四个条件
  date_start_2 <- date - 2 * 10000
  sql_3 <- paste0("select COMPANYCODE,REPORTDATE,FINANCIALRATIOS44 as NPR from FINANCIALRATIOS where REPORTDATE>=",
                  date_start_2, " and REPORTDATE<=", date,
                  " order by COMPANYCODE,REPORTDATE desc")
  data_3 <- sqlQuery(mydb, sql_3)
  data_3 <- merge(data_code, data_3, by = "COMPANYCODE", all.x = TRUE)
  data_3 <- na.omit(data_3)
  symbols_table_3 <- data_3 %>% group_by(SYMBOL) %>%
    summarise(npr_1 = NPR[1], npr_2 = NPR[2], npr_3 = NPR[3], npr_4 = NPR[4],
              npr_5 = NPR[5]) %>%
    filter(npr_1 >= 50, npr_2 >= 50, npr_3 >= 50, npr_4 >= 50, npr_5 >= 50)
  symbols_3 <- symbols_table_3$SYMBOL
  data_npr <- data_3 %>% group_by(SYMBOL) %>%
    summarise(npr = NPR[1])
  # 第一个条件
  # PE
  sql_4 <- paste0("select SYMBOL,TDATE,PE from DERFQUOTE where TDATE=",
                  date," order by SYMBOL")
  data_4 <- sqlQuery(mydb, sql_4)
  data_4$SYMBOL <- handle_symbols(data_4$SYMBOL)
  data_peg <- merge(data_4, data_npr, by = "SYMBOL", all.x = TRUE, all.y = TRUE)
  data_peg <- mutate(data_peg, peg = PE / npr)
  symbols_table_1 <- filter(data_peg, peg > 0.5)
  symbols_1 <- symbols_table_1$SYMBOL
  # intersect conditions
  chosen_symbols <- intersect(symbols_1, symbols_2)
  chosen_symbols <- intersect(chosen_symbols, symbols_3)
  chosen_symbols <- unique(chosen_symbols)
  # 第三个条件
  chosen_symbols_sql <- paste(chosen_symbols, sep = "'", collapse = ",")
  before_day <- date - 10000
  stop_day <- date + 10000
  sql_today <- paste0("select SYMBOL,TDATE,TCLOSE,EXCHANGE from CHDQUOTE_ADJ where SYMBOL in (", chosen_symbols_sql,
                      ") and TDATE>=", before_day, " and TDATE<=", stop_day,
                      " order by SYMBOL,TDATE")
  raw_data <- sqlQuery(mydb, sql_today)
  raw_data$SYMBOL <- handle_symbols(raw_data$SYMBOL)
  show_list <- data.frame(TDATE  = NA, SYMBOL = NA, TCLOSE = NA, EXCHANGE = NA)
  for (i in chosen_symbols)
  {
    data_single <- filter(raw_data, SYMBOL == i)
    if (nrow(data_single) < 60 | !(any(data_single$TDATE == date)))
    {
      next
    }
    data_single <- arrange(data_single, TDATE)
    data_single$mean_60 <- SMA(data_single$TCLOSE, 60)
    if (is.na(data_single$mean_60[which(data_single$TDATE == date)]))
    {
      next
    }
    if (data_single$TCLOSE[which(data_single$TDATE == date)] >
        data_single$mean_60[which(data_single$TDATE == date)])
    {
      tclose <- data_single$TCLOSE[which(data_single$TDATE == date)]
      exchange <- data_single$EXCHANGE[1]
      show_single <- data.frame(TDATE  = date, SYMBOL = i,
                                TCLOSE = tclose, EXCHANGE = exchange)
      show_list <- rbind(show_list, show_single)
    }
  }
  show_list <- show_list[-1, ]
  return(show_list)
}


#' handle the symbol to be XXXXXX character
#'
#' @name handle symbols
#' @param symbols vector
#' @return symbols characterS
handle_symbols <- function(symbols)
{
  for (i in 1:length(symbols))
  {
    if(nchar(symbols[i] < 6))
    {
      while(nchar(symbols[i]) < 6)
      {
        symbols[i] <- paste0('0', symbols[i])
      }
    }
  }
  symbols
}

#' get symbols active after 20160101
#' @import RODBC
get_symbols_choose <- function()
{
  mydb <- odbcConnect(dsn = 'caihua')
  sql <- "SELECT DISTINCT SYMBOL FROM CHDQUOTE_ADJ WHERE TDATE >= 20160101"
  symbol_raw <- sqlQuery(mydb, sql)

  symbol <- as.character(symbol_raw[[1]])

  for (i in 1:length(symbol))
  {
    if(nchar(symbol[i] < 6))
    {
      while(nchar(symbol[i]) < 6)
      {
        symbol[i] <- paste0('0', symbol[i])
      }
    }
  }
  symbol
}
